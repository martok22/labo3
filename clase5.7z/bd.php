<?php
   class Test{
       public function __construct(){
        $con = 'mysql:host=localhost;dbname=cdcol;charset=utf8;';
        $user = "root";
        $clave = "";
        $con = new PDO($con, $user, $clave);
        $sql = $con->query('SELECT * from cds');
        $res = $sql->execute();
        var_dump($res);
       }
   }
    
?>