<?php
include("persona.php");
include("archivos.php");
include("bd.php");
$per1 = new Persona($_REQUEST['nombre'],$_REQUEST['apellido'],$_REQUEST['legajo'],$_REQUEST['edad'],$_REQUEST['nombre_img']);
$arch = new Archivo();
$test;
var_dump($_REQUEST['nombre']);
var_dump($_REQUEST['apellido']);
switch($_REQUEST['accion']){
    case "cargar":
        $arch->Cargar();
    case "modificar":
        $arch->Modificar();
    case "borrar":
        $arch->Borrar();
    case "bd":
        $test = new Test();
        
}
    
?>