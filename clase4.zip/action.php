<?php
include("persona.php");
$per1;
if(!empty($_POST)) 
{
    echo '<br> $POST no está vacío <br>';
    if($_POST['nombre'] =="" || $_POST['apellido'] =="" || $_POST['legajo'] =="" || $_POST['edad'] =="" || !(isset($_FILES))){
        echo "<br> Algún casillero está vacío. Llene todos los campos. <br>";
    }
    else{
        if($_FILES['archivo']['size'] >= 10000000) echo "<br> El archivo no puede superar los 10 mb. <br>";
        else{
            // formo nombre de imagen 
            $extension = explode('.',$_FILES['archivo']['name']);
            $extension = array_reverse($extension)[0];
            $tiempo = time();
            $nombreImg = $_POST['legajo'] . '_' . $tiempo . '.' . $extension;

            // creo persona a partir de los datos $_POST
            $per1 = new Persona($_POST['nombre'],$_POST['apellido'],$_POST['legajo'],$_POST['edad'],$nombreImg);
            if(move_uploaded_file($_FILES['archivo']['tmp_name'],"Imagenes/$nombreImg")) echo "<br>Se movio satisfactoriamente la img temporal a /imagenes<br>";
                else{
                    echo "<br>No se pudo mover la imagen a /imagenes<br>";
            }
            //echo $per1 . "<br>";
            //var_dump($_FILES['archivo']);
            $per1->Cargar();
            if(isset($_POST['modificar'])){
                $per1->Modificar();
            }
            elseif(isset($_POST['guardar'])){ 
                $per1->Guardar();
            }
            elseif(isset($_POST['borrar'])){
                $per1->Borrar(); 
            }
        }
    }
}
echo "<br><br><a href='formulario_completo.html'>VolverA</a>";



/*
switch($_POST){
    
}*/
?>