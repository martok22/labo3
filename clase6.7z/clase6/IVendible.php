<?php  
    interface IVendible{
        public function PrecioMasIva(){
            $precioMasIva = $this->precio + $this->precio * 21/100;
            return $precioMasIva;
        }
    }
?>