<?php
require_once('Cliente.php');
require_once('Helado.php');
$modo = array('a','w');
$nro = 1;
var_dump($modo);
    if(isset($_POST['cargarCliente'])){
        $clie1 = new Cliente($_POST['nombre'],$_POST['clave'],$_POST['correo']);
        $clie1->Guardar($clie1); 
    }
    elseif(isset($_POST['validarCliente'])){
        ($pArchivo=fopen("./clientes/clientesActuales.txt")){
            $listaClientes = array();
            while(!feof($pArchivo)){
                $array[] = explode(",",fgets($pArchivo));
            }
            foreach($listaClientes as $value){
                if($value[1] == $_POST['correo'] || $value[1] == $_POST['clave']){
                    echo "<br>. Usuario logeado <br>.";
                }
                else{
                    echo "<br> Usuario inexistente <br>";
                }
            }  
        }
        if(!fclose($pArchivo))  echo "<br> Error al cerrar archivo <br>";
    }
    elseif(isset($_POST['cargarHelado'])){
        $nombre_img = explode('.',$_FILES['foto']['name']);
        $extension = array_reverse($nombre_img)[0];
        $resto_nombre = $nombre_img[1];
        echo $extension;
        $nombreAGuardar = $resto_nombre . time() . '.' . $extension;
        if(move_uploaded_file($_FILES['archivo']['tmp_name'],"./heladosImagen/$nombreAGuardar")) echo "<br>Se guardo la imagen correctamente <br>";
            else
                echo "<br>No se pudo guardar la imagen<br>";
        }

        $hel1 = new Helado($_POST['sabor'],$_POST['precio'],$nombreAGuardar);
        
        if(file_exists("./helados/sabores.txt")){
            if($pArchivo=fopen("./helados/sabores.txt","a")){
                if($escrito = fwrite($pArchivo,"$hel1") > 0){
                    echo "<br>Se cargo el cliente con exito<br>.";
                }    
                else{
                    echo "<br> Error al escribir el archivo <br>";
                }
            }
            if(!fclose($pArchivo)) echo "<br> Error al cerrar el archivo. <br>";
        }else{
            if($pArchivo=fopen("./helados/sabores.txt","w")){
                if($escrito = fwrite($pArchivo,$ > 0){
                    echo "<br>Se cargo el cliente con exito<br>.";
                }    
                else{
                    echo "<br> Error al escribir el archivo <br>";
                }
            }
            if(!fclose($pArchivo)) echo "<br> Error al cerrar el archivo. <br>";
        }
    }elseif(isset($_POST['vender'])){
        $helado;
        $helado_a_Escribir;
        $nohay=false;
        if($pArchivo=fopen("./helados/sabores.txt","r")){
            $listaHelados = array();
            while(!feof($pArchivo)){
                $array[] = explode(",",fgets($pArchivo));
            }
            foreach($listaHelados as $value){
                if($value[0] == $_POST['sabor']){
                    $helado = new Helado($helado->sabor = $value[0],$helado->precio = $value[1],"");
                    $nohay=true;
                    $helado_a_Escribir = $helado->sabor . ',' . $_POST['cantidad'] . ',' . $helado->precio;
                }
            }
            if($nohay) echo "No hay del sabor indicado <br>.";
            else{
                echo "El helado de " . $helado->sabor . " cuesta " . '$' . $helado->PrecioMasIva() . '.';

            }      
        }
        fclose($pArchivo);
        if(file_exists("./helados/vendidos.txt")){
            if($pArchivo=fopen("./helados/vendidos.txt","a")){
                if($escrito = fwrite($pArchivo,"$helado_a_Escribir") > 0){
                    echo "<br>Se escribió el helado con éxito. <br>.";
                }    
                else{
                    echo "<br> Error al escribir el archivo <br>";
                }
            }
            if(!fclose($pArchivo)) echo "<br> Error al cerrar el archivo. <br>";
        }else{
            if($pArchivo=fopen("./helados/vendidos.txt","w")){
                if($escrito = fwrite($pArchivo,"$helado_a_Escribir")) > 0){
                    echo "<br>Se cargo el cliente con exito<br>.";
                }    
                else{
                    echo "<br> Error al escribir el archivo <br>";
                }
            }
            if(!fclose($pArchivo)) echo "<br> Error al cerrar el archivo. <br>";
        }
    }
    }
?>