<?php
include_once("IVendible.php");
    class Helado extends IVendible{
        private $sabor;
        private $precio;
        private $dir_foto;

        public function __construct($sab,$pre,$dir_fo){
            $this->sabor=$sab;
            $this->precio=$pre;
            $this->dir_foto=$dir_fo;
        }
        
        
    }
    ?>