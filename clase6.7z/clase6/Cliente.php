<?php
    class Cliente{
        private $nombre;
        private $clave;
        private $correo;

        public function __construct($nom,$cla,$corr){
            $this->nombre=$nom;
            $this->clave=$cla;
            $this->correo=$corr;
        }

        public function __toString(){
            $frase = $this->nombre . "," . $this->clave . "," . $this->correo . PHP_EOL;
            return $frase;
        }

        public function Guardar($clie1){
            
            if(file_exists("./clientes/clientesActuales.txt")){
                if($pArchivo=fopen("./clientes/clientesActuales.txt","a")){
                    if($escrito = fwrite($pArchivo,"$clie1") > 0){
                        echo "<br>Se cargo el cliente con exito<br>.";
                    }    
                    else{
                        echo "<br> Error al escribir el archivo <br>";
                    }
                }
                if(!fclose($pArchivo)) echo "<br> Error al cerrar el archivo. <br>";
            }else{
                if($pArchivo=fopen("./clientes/clientesActuales.txt","w")){
                    if($escrito = fwrite($pArchivo,$clie1->toString()) > 0){
                        echo "<br>Se cargo el cliente con exito<br>.";
                    }    
                    else{
                        echo "<br> Error al escribir el archivo <br>";
                    }
                }
                if(!fclose($pArchivo)) echo "<br> Error al cerrar el archivo. <br>";
            }
        }

        
    
    }