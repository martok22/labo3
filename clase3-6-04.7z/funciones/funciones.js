

function saludar(){
    alert("Hola mundo!");
}

function CalcularSuma(){
    var num1 = parseInt(document.getElementById("num1").value);
    var num2 = parseInt(document.getElementById("num2").value); // ojo que el input number devuelve string por ser codigo html
    // se puede usar el innerHtml con elemtos html q por ej, no sean input
    var suma = num1+num2;
    suma = suma.toString();
    document.getElementById("resultado").value = suma;
    
         
}

function CalcularSumaGuardar(){
    //CalcularSuma();
    var tbody = document.getElementById('tabla');
    var num1, num2, result;
    num1 = document.getElementById('num1').value;
    num2 = document.getElementById('num2').value;
    result = document.getElementById('resultado').value;
    var cuerpoViejo = tbody.innerHTML;
    tbody.innerHTML = cuerpoViejo + "<tr>" + "<td>" + num1 + "</td>" + "<td>" + num2 + "</td>" + "<td>" + result + "</td></tr>";
    
    
    
    //document.getElementByName("num1guardado").value;
    //document.getElementByName("num2guardado").value;
}

