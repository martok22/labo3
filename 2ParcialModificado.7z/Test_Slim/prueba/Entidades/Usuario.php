<?php

class Usuario
{
    public $id;
    public $nombre;
    public $clave;

    public function MostrarDatos()
    {
            return $this->id." - ".$this->nombre." - ".$this->clave;
    }
    
    public static function TraerUnUsuarioclaveParamNombreArray($id, $clave)
    {    
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT id AS id, nombre AS nombre, "
                                                        . "clave AS clave FROM Usuarios WHERE id = :id "
                                                        . "AND clave= :clave");
        
        $consulta->execute(array(":id" => $id, ":clave" => $clave));
        
        $UsuarioBuscado = $consulta->fetchObject('Usuario');
        
        return $UsuarioBuscado; 
    }
    
    public function InsertarElUsuarioParametros()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        
        $consulta =$objetoAccesoDato->RetornarConsulta("INSERT INTO Usuarios (id, nombre, clave)"
                                                    . "VALUES(:id, :nombre, :clave)");
        
        $consulta->bindValue(':id', $this->id, PDO::PARAM_INT);
        $consulta->bindValue(':clave', $this->clave, PDO::PARAM_STR);
        $consulta->bindValue(':nombre', $this->nombre, PDO::PARAM_STR);

        $consulta->execute();   

    }
    
    public static function ModificarUsuario($id, $precio, $clave)
    {

        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        
        $consulta =$objetoAccesoDato->RetornarConsulta("UPDATE Usuarios SET id = :id, nombre = :nombre, 
                                                        clave = :clave WHERE id = :id");
        
        $consulta->bindValue(':id', $id, PDO::PARAM_INT);
        $consulta->bindValue(':precio', $precio, PDO::PARAM_FLOAT);
        $consulta->bindValue(':clave', $clave, PDO::PARAM_STR);

        return $consulta->execute();

    }

    public static function EliminarUsuario($id)
    {

        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        
        $consulta =$objetoAccesoDato->RetornarConsulta("DELETE FROM Usuarios WHERE id = :id");
        
        $consulta->bindValue(':id', $id, PDO::PARAM_INT);

        return $consulta->execute();

    }
    
}