<?php

class Media
{
    public $id;
    public $color;
    public $marca;
    public $precio;
    public $talle;

    public function MostrarDatos()
    {
            return $this->id." - ".$this->color." - ".$this->marca ." - ".$this->precio . " - ".$this->talle;
    }
    
    public static function TraerUno($id, $marca)
    {    
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT id AS id, color AS color, "
                                                        . "marca AS marca FROM Medias WHERE id = :id "
                                                        . "AND marca= :marca");
        
        $consulta->execute(array(":id" => $id, ":marca" => $marca));
        
        $MediaBuscado = $consulta->fetchObject('Media');
        
        return $MediaBuscado; 
    }
    
    public static function InsertarMedia($id, $precio, $marca, $color, $talle)
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        
        $consulta =$objetoAccesoDato->RetornarConsulta("INSERT INTO Medias (id, color, marca)"
                                                    . "VALUES(:id, :color, :marca)");
        
        $consulta->bindValue(':id', $id, PDO::PARAM_INT);
        $consulta->bindValue(':marca', $talle, PDO::PARAM_STR);
        $consulta->bindValue(':color', $color, PDO::PARAM_STR);
        $consulta->bindValue(':precio', $precio, PDO::PARAM_FLOAT);
        $consulta->bindValue(':talle', $marca, PDO::PARAM_STR);

        $consulta->execute();   

    }
    
    public static function ModificarMedia($id, $precio, $marca, $color, $talle)
    {

        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        
        $consulta =$objetoAccesoDato->RetornarConsulta("UPDATE Medias SET id = :id, color = :color, 
                                                        marca = :marca WHERE id = :id");
        
        $consulta->bindValue(':id', $id, PDO::PARAM_INT);
        $consulta->bindValue(':precio', $precio, PDO::PARAM_FLOAT);
        $consulta->bindValue(':marca', $marca, PDO::PARAM_STR);
        $consulta->bindValue(':color', $color, PDO::PARAM_STR);
        $consulta->bindValue(':talle', $talle, PDO::PARAM_STR);

        return $consulta->execute();

    }

    public static function EliminarMedia($id)
    {

        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        
        $consulta =$objetoAccesoDato->RetornarConsulta("DELETE FROM Medias WHERE id = :id");
        
        $consulta->bindValue(':id', $id, PDO::PARAM_INT);

        return $consulta->execute();

    }
    
}