<?php

    use \Psr\Http\Message\ServerRequestInterface as Request;
    use \Psr\Http\Message\ResponseInterface as Response;

    require_once './vendor/autoload.php';
    require_once 'Entidades/Media.php';
    require_once 'Entidades/AccesoDatos.php';

    $config['displayErrorDetails'] = true;
    $config['addContentLengthHeader'] = false;

    $app = new \Slim\App(["settings" => $config]);

    $app->post("[/altaMedia]" , function(Request $request , Response $response) {

        $body =  $request->getParsedBody();
        Media::Insertar($body['id'],$body['precio'],$body['marca'],$body['color'],$body['talle']);
        return $response;
    });

    $

    $app->run();
?>