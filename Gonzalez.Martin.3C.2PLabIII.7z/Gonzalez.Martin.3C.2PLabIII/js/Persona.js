var Modelo;
(function (Modelo) {
    var Persona = /** @class */ (function () {
        function Persona(id, nombre, apellido) {
            this.nombre = nombre;
            this.id = id;
            this.apellido = apellido;
        }
        /*public toJSON():object{
            return JSON.parse("{nombre: "+this.nombre+"}");
        }*/
        Persona.prototype.toString = function () {
            return this.GetId() + '-' + this.GetNombre();
        };
        Persona.prototype.GetNombre = function () {
            return this.nombre;
        };
        Persona.prototype.GetId = function () {
            return this.id;
        };
        Persona.prototype.GetApellido = function () {
            return this.apellido;
        };
        return Persona;
    }());
    Modelo.Persona = Persona;
})(Modelo || (Modelo = {}));
