/// <reference path="Persona.ts"/>
/// <reference path="Alumno.ts"/>
/// <reference path="Funciones.ts"/>

namespace Modelo{

    Funciones.OnLoad();
    
}