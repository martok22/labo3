/// <reference path="Persona.ts"/>
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
//import Persona = require("./js/Persona.ts");
var Modelo;
(function (Modelo) {
    var Cliente = /** @class */ (function (_super) {
        __extends(Cliente, _super);
        function Cliente(id, nombre, apellido, sexo, edad) {
            var _this = _super.call(this, id, nombre, apellido) || this;
            _this.sexo = sexo;
            _this.edad = edad;
            return _this;
        }
        Cliente.ObjetoAJASON = function (objeto) {
            var miObjetoJson = {
                id: objeto.GetId(),
                nombre: objeto.GetNombre(),
                apellido: objeto.GetApellido(),
                sexo: objeto.GetSexo(),
                edad: objeto.GetEdad()
            };
            return miObjetoJson;
        };
        Cliente.ListaJasonAListaObjeto = function (lista) {
            var retorno = [];
            lista.forEach(function (objeto) {
                retorno.push(Cliente.JASONAObjeto(objeto));
            });
            return retorno;
        };
        Cliente.ListaClienteAListaJASON = function (lista) {
            var retorno = [];
            lista.forEach(function (objeto) {
                retorno.push(Cliente.ObjetoAJASON(objeto));
            });
            return retorno;
        };
        Cliente.JASONAObjeto = function (jason) {
            return new Cliente(jason.id, jason.nombre, jason.apellido, jason.sexo, jason.edad);
        };
        Cliente.prototype.GetApellido = function () {
            return this.apellido;
        };
        Cliente.prototype.GetSexo = function () {
            return this.sexo;
        };
        Cliente.prototype.GetEdad = function () {
            return this.edad;
        };
        Cliente.prototype.toString = function () {
            return _super.prototype.toString.call(this) + '-' + this.GetApellido() + '-' + this.GetSexo() + '-' + this.GetEdad();
        };
        return Cliente;
    }(Modelo.Persona));
    Modelo.Cliente = Cliente;
})(Modelo || (Modelo = {}));
