/// <reference path="Cliente.ts"/>

namespace Modelo{
    
    export class Funciones{
        
        public static idCount;

        public static OnLoad():void{
            let lista:Cliente[] = Funciones.Generar();
            Funciones.LoadStorage(Cliente.ListaClienteAListaJASON(lista));
            Funciones.idCount = lista.length + 1;
            $(document).ready(function(){
                Funciones.CargarGrilla(lista); // Cargo grilla
                Funciones.Promedio(); // Cargo estadísticas
            }); 
        }

        public static CortejarCampos():boolean{
            
            // Si estan vacios
            let boleano:boolean = false;
            if($('#nombre').val()=='' || $('#nombre').val()==undefined) boleano=true;
            if($('#apellido').val()=='' || $('#apellido').val()==undefined) boleano=true;
            if($('#edad').val()=='' || $('#edad').val()==undefined) boleano=true;
            if($('#sexo').val()=='' || $('#sexo').val()==undefined) boleano=true;
            
            //Si el ID es duplicado
            if(Funciones.BuscarPorId(($('#id').attr('placeholder')))) boleano=true;
            
            return boleano;

        }


        public static ObtenerCliente(id?:number):Cliente{ //Sin id -> Agregar - Con id -> Modificar
            let inputsID:string[] = [];
            (id!=null) ? (inputsID = inputsID.concat([id.toString(),'#nombreModal','#legajoModal','#materiaModal','#SexoModal'])) : (inputsID = inputsID.concat([Funciones.idCount.toString(),'#nombre','#apellido','#sexo','#edad']));
            let Alu:Cliente = new Cliente((Number)(inputsID[0]),
                                        (String)($(inputsID[1]).val()),
                                        (String)($(inputsID[2]).val()),
                                        (String)($(inputsID[3]).val()),
                                        (Number)($(inputsID[4]).val()));
            Funciones.idCount++;
            return Alu;
        } 

        public static CargarGrilla(lista:Cliente[]):void{
            ($('#grilla')).html(Funciones.PopularGrilla(lista));
        }

        public static DumpStorage():ClienteJASON[]{
            let listaString:string = localStorage.getItem('listaClientes');
            let listaJSON:ClienteJASON[] = JSON.parse(listaString);
            return listaJSON;
        }

        public static BuscarPorId(id:string):boolean{
            
            let lista:ClienteJASON[] = Funciones.DumpStorage();
            let cliente:ClienteJASON;
            lista.forEach(function(cliente){
                 if(id==cliente.id.toString()) return true;
            });
            return false;
        }


        public static LimpiarStorage(){
            localStorage.clear();
        }

        public static LoadStorage(listaJSON:ClienteJASON[]):void{
            localStorage.setItem('listaClientes',JSON.stringify(listaJSON));
        }
        public static LlenarCampos(id:number):void{
            
            let lista:ClienteJASON[] = Funciones.DumpStorage();
           
            lista.forEach(function(cliente){
                if(id==cliente.id){
                    $('#id').attr('placeholder',cliente.id.toString());
                    $('#nombre').val(cliente.nombre);
                    $('#apellido').val(cliente.apellido);
                    $('#edad').val(cliente.edad);
                    $('#sexo').val(cliente.sexo);

                    Funciones.AgregarAttribute(cliente.id);
                }
            });
        }

        public static Accion(accion:string,id?:number):boolean{
            
            if(Funciones.CortejarCampos()) return false;
            let listaJSON:ClienteJASON[] = Funciones.DumpStorage();

            if(accion=='Agregar'){
                listaJSON.push(Cliente.ObjetoAJASON(Funciones.ObtenerCliente()));
            }
            else{
                listaJSON.forEach(function(objeto:ClienteJASON,index,lista){
                
                    if(accion=='Modificar'){
                        if(id!=null && objeto.id==id) {
                            lista[index] = Cliente.ObjetoAJASON(Funciones.ObtenerCliente(id));
                        }
                    } 
                    else if(accion == 'Borrar'){
                        if(id!=null && objeto.id==id) {
                            lista.splice(index,1);
                            //Rebajo ID
                            lista.forEach(function(cliente,indexAdentro,lista){
                                if(indexAdentro>=index) lista[indexAdentro].id--;
                            })
                        }
                    }
                })
            }
            Funciones.CargarGrilla(Cliente.ListaJasonAListaObjeto(listaJSON));
            Funciones.LoadStorage(listaJSON);
            return true;
        }
        

        public static Generar():Cliente[]{
            let miLista:Cliente[] = [];
            miLista.push(new Cliente(1,'Martin','Gimenez','Masculino',24));
            miLista.push(new Cliente(2,'Florencia','Zapata','Femenino',18));
            miLista.push(new Cliente(3,'German','Zapata','Masculino',9));
            return miLista;
            
        }


        public static Promedio():void{
            let lista:ClienteJASON[] = Funciones.DumpStorage();
            let sumaSexos:number = lista.reduce(function(acum,alu,index,lista){
                acum = acum + alu.edad;
                return acum;
            },0);
             $('#calcularProm').html((sumaSexos / lista.length).toFixed(2).toString());
        }

        public static Filtrar(){

            let inputSexo:string = (String)($('#searchBarSexo').val());
            let lista = Funciones.DumpStorage();
            lista = lista.filter(function(objeto){
                return objeto.sexo.toString().startsWith(inputSexo,0);
            });             
            Funciones.CargarGrilla(Cliente.ListaJasonAListaObjeto(lista));
        }

        public static AgregarAttribute(id:number):void{
            ($('#eliminar')).attr('onclick','Modelo.Funciones.Accion("Borrar",'+id+')');
        }

        public static PopularGrilla(lista:Cliente[]):string{
            let tabla_string:string = "";

            // Encabezados
            tabla_string += '<div class="row">'
            tabla_string += '<div class="col-xs-2 col-sm-2 col-md-2" style="background-color:lavender">ID</div>'
            tabla_string += '<div class="col-xs-3 col-sm-3 col-md-3" style="background-color:lavender">Nombre</div> '
            tabla_string += '<div class="col-xs-2 col-sm-2 col-md-2" style="background-color:lavender">Apellido</div>'
            tabla_string += '<div class="col-xs-3 col-sm-3 col-md-3" style="background-color:lavender">Edad</div> '
            tabla_string += '<div class="col-xs-2 col-sm-2 col-md-2" style="background-color:lavender">Sexo</div> ' 
            tabla_string += '</div>';

            for(let contador=0; contador<lista.length ;contador++){

                //
                tabla_string += "<div class='row'><button class='col-lg-12' onclick='Modelo.Funciones.LlenarCampos("+lista[contador].GetId()+")'><div class='row'>"; 
                tabla_string += '<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2" style="background-color:lightcyan">' +lista[contador].GetId()+ '</div> ';
                tabla_string += '<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3" style="background-color:lightcyan">' +lista[contador].GetNombre()+ '</div> ';
                tabla_string += '<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2" style="background-color:lightcyan">' +lista[contador].GetApellido()+ '</div> '; 
                tabla_string += '<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3" style="background-color:lightcyan">' +lista[contador].GetEdad()+ '</div> ';
                tabla_string += '<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2" style="background-color:lightcyan">' +lista[contador].GetSexo()+ '</div> ';
                
                tabla_string += "</div></button></div>"; 
            }
            
            return tabla_string;
        }

    }
}
