/// <reference path="Persona.ts"/>
/// <reference path="Alumno.ts"/>
/// <reference path="Funciones.ts"/>
var Modelo;
(function (Modelo) {
    Modelo.Funciones.OnLoad();
})(Modelo || (Modelo = {}));
