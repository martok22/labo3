/// <reference path="Persona.ts"/>

//import Persona = require("./js/Persona.ts");
namespace Modelo{
    
    export type ClienteJASON = {id:number,nombre:string,apellido:string,sexo:string,edad:number};

    export class Cliente extends Persona{

        private sexo:string;
        private edad:number;

        constructor(id:number, nombre:string, apellido:string, sexo:string, edad:number){
            super(id,nombre,apellido);
            this.sexo = sexo;
            this.edad = edad;
        }

        public static ObjetoAJASON(objeto:Cliente):ClienteJASON{
           
            let miObjetoJson:ClienteJASON = {
                id: objeto.GetId(),
                nombre: objeto.GetNombre(),
                apellido: objeto.GetApellido(),
                sexo: objeto.GetSexo(),
                edad: objeto.GetEdad(),
            }
            return miObjetoJson;
        }

        public static ListaJasonAListaObjeto(lista:ClienteJASON[]){

            let retorno:Cliente[] = [];
            lista.forEach(function(objeto){
                retorno.push(Cliente.JASONAObjeto(objeto));
            });
            return retorno;
        }

        public static ListaClienteAListaJASON(lista:Cliente[]){

            let retorno:ClienteJASON[] = [];
            lista.forEach(function(objeto){
                retorno.push(Cliente.ObjetoAJASON(objeto));
            });
            return retorno;
        }

        public static JASONAObjeto(jason:ClienteJASON):Cliente{
            return new Cliente(jason.id,jason.nombre,jason.apellido,jason.sexo,jason.edad);
        }

        public GetApellido():string{
            return this.apellido;
        }

        public GetSexo():string{
            return this.sexo;
        }

        public GetEdad():number{
            return this.edad;
        }

        public toString():string{
            return super.toString()+'-'+this.GetApellido()+'-'+this.GetSexo()+'-'+this.GetEdad();
        }

    }
}

