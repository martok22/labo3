namespace Modelo{
    export class Persona {
        
        protected nombre:string;
        protected id:number;
        protected apellido:string;
    
        constructor(id:number,nombre:string,apellido:string){
            this.nombre = nombre;
            this.id = id;
            this.apellido = apellido;
        }

        /*public toJSON():object{
            return JSON.parse("{nombre: "+this.nombre+"}");
        }*/

        public toString():string{
            return this.GetId()+'-'+this.GetNombre();
        }


        public GetNombre():string{
            return this.nombre;
        }
        

        public GetId():number{
            return this.id;
        }

        public GetApellido():string{
            return this.apellido;
        }
    }

}

