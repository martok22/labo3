<?php
    class Archivo{

        public static function obtenerObjeto($array,$nombreClase){
            if($nombreClase=='Helado'){
                return new Helado($array[0],$array[1],trim($array[2]));
            }
            else if($nombreClase=='Cliente'){
                return new Cliente($array[0],$array[1],trim($array[2]));
            }
        }

        public static function Guardar($path, $objeto, $modo){
            if($pArchivo = fopen($path,$modo)){
                $escrito = fwrite($pArchivo,$objeto);
                if($escrito != strlen($objeto))
                        "<br> Error al escribir el archivo. <br>";
            if(!fclose($pArchivo))
                echo "<br> Error al cerrar el archivo. <br>";
            }
            else
                echo "<br> Error al abrir el archivo. <br>";
        }

        public static function Leer($path,$nombreClase){
            $lineaLeida = array();
            $arrayObjetos = array();
            if($pArchivo=fopen($path,"r")){
                while(!feof($pArchivo)){
                    $lineaLeida = explode(",",fgets($pArchivo,filesize($path)));
                    if(count($lineaLeida)>1){
                        array_push($arrayObjetos,Archivo::obtenerObjeto($lineaLeida,$nombreClase));
                    }
                }
                if(!fclose($pArchivo))
                    echo "<br> Error al cerrar el archivo. <br>";
            }
            else
                echo "<br> Error al abrir el archivo. <br>";
            return $arrayObjetos;
        }

    
        
    }
    ?>