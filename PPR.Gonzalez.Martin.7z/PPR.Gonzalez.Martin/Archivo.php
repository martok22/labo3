<?php
    class Archivo{

        public static function obtenerObjeto($linea,$nombreClase){
            if($nombreClase=='Helado'){
                return new Helado($linea[0],$linea[1],$linea[2], trim($linea[3]));
            }
            else if($nombreClase=='Venta'){
                return new Venta($linea[0],$linea[1],$linea[2],$linea[3],$linea[4]);
            }
            else if($nombreClase=='VentaConImagen'){
                return new VentaConImagen($linea[0],$linea[1],$linea[2],$linea[3],$linea[4],$linea[5]);
            }
        }

        public static function Guardar($path, $objeto, $modo){
            if($pArchivo = fopen($path,$modo)){
                $escrito = fwrite($pArchivo,$objeto);
                if($escrito != strlen($objeto))
                        "<br> Error al escribir el archivo. <br>";
            if(!fclose($pArchivo))
                echo "<br> Error al cerrar el archivo. <br>";
            }
            else
                echo "<br> Error al abrir el archivo. <br>";
        }

        public static function Leer($path,$nombreClase){
            $array = array();
            $arrayObjetos = array();
            if($pArchivo=fopen($path,"r")){
                while(!feof($pArchivo)){
                    $array = explode(",",fgets($pArchivo,filesize($path)));
                    if(count($array)>1){
                        array_push($arrayObjetos,Archivo::obtenerObjeto($array,$nombreClase));
                    }
                }
                if(!fclose($pArchivo))
                    echo "<br> Error al cerrar el archivo. <br>";
            }
            else
                echo "<br> Error al abrir el archivo. <br>";
            return $arrayObjetos;
        }

    
        
    }
    ?>