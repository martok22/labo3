<?php
    require_once("Helado.php");
    require_once("Archivo.php");
    require_once("Venta.php");
    require_once("VentaConImagen.php");

    const rutaImagen = "./imagenesDeLaVenta/";
    const rutaBackupImagenes = "./heladosImagenesBackup/";
    const rutaHelados = "./heladosArchivo/Helados.txt";
    const rutaVentas = "./ventasArchivo/Ventas.txt";

    switch($_REQUEST['accion']){

        case 'altaVenta':
            if(isset($_POST['sabor'],$_POST['tipo'],$_POST['cantidad'], $_POST['correo'])){
                $listaHelados = Archivo::Leer(rutaHelados,'Helado');
                $contador = 0;
                var_dump($listaHelados);
                foreach($listaHelados as $value){
                    //echo $value->getSabor() . $value->getTipo();
                    if($value->getSabor() == $_POST['sabor'] && $value->getTipo() == $_POST['tipo'])
                    {
                        if($value->getCantidad()>=$_POST['cantidad'])
                        {
                            $listaHelados[$contador]->setCantidad(($value->getCantidad())-($_POST['cantidad']));
                            Archivo::Guardar(rutaVentas,new Venta($_POST['sabor'],$value->getPrecio(),$_POST['cantidad'],$_POST['tipo'],$_POST['correo']),"a");
                        }
                    }
                    $contador++;      
                }
                unlink(rutaHelados);
                foreach($listaHelados as $value){
                    if($value!='' && $value != null){
                        Archivo::Guardar(rutaHelados,$value,"a");
                    }
                }
            }


        break;
        case 'consultarHelado':

        $listaHelados = Archivo::Leer(rutaHelados,'Helado');
        //var_dump($listaHelados);
        $hay = false;
        foreach($listaHelados as $value){
            if($value->getSabor() == $_POST['sabor'] && $value->getTipo() == $_POST['tipo'])
            {
                echo "<br> Si hay. <br>"; $hay=true;
                break;
            }      
        }
        if(!$hay) echo "<br> No hay <br>";
        break;

        case 'heladoCarga':

        if(isset($_GET['sabor'], $_GET['precio'], $_GET['tipo'], $_GET['cantidad'])){
            $helado = new Helado($_GET['sabor'],$_GET['precio'], $_GET['cantidad'],$_GET['tipo']);
            Archivo::Guardar(rutaHelados,$helado,"a");
        }

        break;

        case 'altaVentaConImagen':
        
        if(isset($_POST['sabor'],$_POST['tipo'],$_POST['cantidad'], $_POST['correo'], $_FILES['imagen'])){
            
            $listaHelados = Archivo::Leer(rutaHelados,'Helado');
            //var_dump($listaHelados);
            foreach($listaHelados as $value){

                if($value->getSabor() == $_POST['sabor'] && $value->getTipo() == $_POST['tipo'])
                {
                    if($value->getCantidad()>=$_POST['cantidad'])
                    {
                        $value->setCantidad(($value->getCantidad())-($_POST['cantidad']));
                        
                        $nombreImg = $_POST['sabor'] . date('d_m_Y') . '.' . pathinfo($_FILES['imagen']['name'],PATHINFO_EXTENSION);
                        move_uploaded_file($_FILES['foto']['tmp_name'],rutaImagen . $nombreImg;

                        Archivo::Guardar(rutaVentas,new VentaConImagen($_POST['sabor'],$value->getPrecio(),$_POST['cantidad'],$_POST['tipo'],$_POST['correo'],$nombreImg),"a");
                    }
                }      
            }
        }
        break;

        case 'tablaVentas':
        
        /*function comparador($a, $b) {
            if ($a->getPrecio() == $b->getPrecio()) {
                return 0;
            }
            return ($a->getPrecio() < $b->getPrecio()) ? 1 : -1; // mayor a menor
        }
        uasort($array, 'comparador');*/

        $array = Archivo::Leer(rutaVentas,'Venta');
        
        $tabla = "<table border='1'>
        <tbody>
            <thead>
                <th>Sabor</th>
                <th>Precio</th>
                <th>Cantidad</th>
                <th>Tipo</th>
                <th>Correo</th>
            </thead>";
        if(isset($_GET['sabor'],$_GET['correo'])){
            foreach($array as $item) {
                if($item->getSabor() == $_GET['sabor'] && $item->getCorreo() == $_GET['correo']){
                    $tabla .= "<tr>
                    <td>".$item->getSabor()."</td>
                    <td>".$item->getPrecio()."</td>
                    <td>".$item->getCantidad()."</td>
                    <td>".$item->getTipo()."</td>
                    <td>".$item->getCorreo()."</td>
                
                </tr>";
                }
                
        }}
        else if(isset($_GET['sabor'])){
            foreach($array as $item) {
                if($item->getSabor() == $_GET['sabor']){
                    $tabla .= "<tr>
                    <td>".$item->getSabor()."</td>
                    <td>".$item->getPrecio()."</td>
                    <td>".$item->getCantidad()."</td>
                    <td>".$item->getTipo()."</td>
                    <td>".$item->getCorreo()."</td>
                
                </tr>";
                }
            }
        }
        else if(isset($_GET['correo'])){
            foreach($array as $item) {
                if(trim($item->getCorreo()) == $_GET['correo']){
                    $tabla .= "<tr>
                    <td>".$item->getSabor()."</td>
                    <td>".$item->getPrecio()."</td>
                    <td>".$item->getCantidad()."</td>
                    <td>".$item->getTipo()."</td>
                    <td>".$item->getCorreo()."</td>
                
                </tr>";
                }
            }
        }
        else
        {
            foreach($array as $item) {
                    $tabla .= "<tr>
                    <td>".$item->getSabor()."</td>
                    <td>".$item->getPrecio()."</td>
                    <td>".$item->getCantidad()."</td>
                    <td>".$item->getTipo()."</td>
                    <td>".$item->getCorreo()."</td>
                
                </tr>";
                
        }
            
        }

        $tabla .= "</tbody></table>";
        echo $tabla;
        
        break;
        
    }


?>