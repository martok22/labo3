<?php
    require_once("Cliente.php");
    require_once("Helado.php");
    require_once("Archivo.php");

    const rutaImagen = "./heladosImagenes/";
    const rutaBackupImagenes = "./heladosImagenesBackup/";
    const rutaHelados = "./heladosArchivo/helados.txt";
    const rutaClientes = "./clientesArchivo/clientes.txt";

    switch($_REQUEST['accion']){

        case 'cargaCliente':

            $matchCorreo = false;
            if(file_exists(rutaClientes)){
                $array = ARchivo::Leer(rutaClientes,'Cliente');
                foreach($array as $value){
                    if($value->getCorreo() == $_GET['correo']){
                        echo "<br> Correo existente. Ingrese otro. <br>";
                        $matchCorreo = true;
                        break;
                    }
                }
            }
            if(isset($_GET['nombre'],$_GET['correo'],$_GET['clave']) && !$matchCorreo)
                Archivo::Guardar(rutaClientes,new Cliente($_GET['nombre'],$_GET['correo'],$_GET['clave']),"a");

        break;
        case 'validarCliente':

        $listaClientes = Archivo::Leer(rutaClientes,'Cliente');
        $login = false;
        foreach($listaClientes as $value){
            if($value[1]->correo == $_POST['correo'] && $value[2]->clave == ($_POST['clave'] . PHP_EOL))
            {
                echo "<br>. Usuario Logeado. <br>"; $login=true;
                break;
            }      
        }
        if(!$login) echo "<br> Usuario no encontrado. <br>";
        break;

        case 'altaHelado':

        if(isset($_POST['sabor'], $_POST['precio'], $_FILES['foto'])){

            $nombreImg = $_POST['sabor'] . date('d_m_Y') . '.' . pathinfo($_FILES['foto']['name'],PATHINFO_EXTENSION);
            $helado = new Helado($_POST['sabor'],$_POST['precio'],$nombreImg);
            if(move_uploaded_file($_FILES['foto']['tmp_name'],rutaImagen . $nombreImg)) echo "Se movio la imagen";
            Archivo::Guardar(rutaHelados,$helado,"a");
        }

        break;

        case 'borrarHelado':

        $array = Archivo::Leer(rutaHelados,'Helado');
        var_dump($array);
        if(isset($_GET['sabor'])){
                foreach($array as $value){
                    if ($value->getSabor() == $_GET['sabor']) echo "<br> El sabor está en la lista <br>";
                    else
                        echo "<br> El sabor no está en la lista <br>";
                }
            }
        var_dump($array);
        var_dump($_POST['sabor']);
        if(isset($_POST['sabor']) && $_POST['queDeboHacer'] == 'borrar'){
            $count = 0;
            foreach($array as $value){
                if ($value->getSabor() == $_POST['sabor']){
                    copy(rutaImagen . trim($value->getImagen()),rutaBackupImagenes . trim($value->getImagen()));
                    unset($array[$count]);
                } 
                $count++;
            }
            var_dump($array);

            $contador = 0;
            unlink(rutaHelados);
            foreach($array as $value){
                if($value!='' && $value != null){
                    Archivo::Guardar(rutaHelados,$value,"a");
                }
            }
        }

        break;

        case 'modificarHelado':
        
        $array = Archivo::Leer(rutaHelados,'Helado');
        if(isset($_POST['sabor'])){
            $match=false;
            foreach($array as $value){
                if ($value->getSabor() == $_POST['sabor']){
                    $match=true;

                    $value->setPrecio($_POST['precio']);
                    $nombreImg = $_POST['sabor'] . date('d_m_Y') . '.' . pathinfo($_FILES['imagen']['name'],PATHINFO_EXTENSION);
                    $value->setImagen($nombreImg);

                    move_uploaded_file($_FILES["imagen"]["tmp_name"] , rutaBackupImagenes . $value->getImagen());
                    unlink(rutaImagen . $value->getImagen());
                }
            }
            if(!$match) echo "<br> No hay coincidencias para los datos buscados. <br>";
        }

        unlink(rutaHelados);
            foreach($array as $value){
                if($value!='' && $value != null){
                    Archivo::Guardar(rutaHelados,$value,"a");
                }
            }
        break;

        case 'mostrarHelados':
        
        /*function comparador($a, $b) {
            if ($a->getPrecio() == $b->getPrecio()) {
                return 0;
            }
            return ($a->getPrecio() < $b->getPrecio()) ? 1 : -1; // mayor a menor
        }
        uasort($array, 'comparador');*/

        $array = Archivo::Leer(rutaHelados,'Helado');
        $tabla = "<table border='1'>
        <tbody>
            <thead>
                <th>Sabor</th>
                <th>Precio</th>
                <th>Imagen</th>
            </thead>";

        foreach($array as $item) {
        $tabla .= "<tr>
                    <td>".$item->getSabor()."</td>
                    <td>".$item->getPrecio()."</td>
                    <td><img src=".rutaImagen.trim($item->GetImagen())."></td>
                </tr>";
        }

        $tabla .= "</tbody></table>";
        echo $tabla;
        echo "<br> <img src=".rutaImagen.trim($item->GetImagen()).">";
        }


?>