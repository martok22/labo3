<?php
    class VentaConImagen extends Venta{
        private $imagen;

        public function __construct($sabor, $precio, $cant, $tipo, $correo, $imagen){
            parent::setCorreo($correo);
            parent::setSabor($sabor);
            parent::setPrecio($precio);
            parent::setCantidad($cant);
            parent::setTipo($tipo);
            $this->setImagen($imagen);
        }

        public function setImagen($imagen){
            $this->imagen = $imagen;
        }

        public function __toString()
        {
            return trim(parent::__toString()) . ',' . $this->imagen . PHP_EOL;
        }

    }