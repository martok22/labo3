<?php   
    class Helado {
        private $sabor;
        private $precio;
        private $cantidad;
        private $tipo;

        public function __construct($sab, $prec, $cant, $tipo)
        {
            $this->sabor = $sab;
            $this->precio = $prec;
            $this->tipo = $tipo;
            $this->cantidad = $cant;
        }

        public function getSabor(){
            return $this->sabor;
        }

        public function getPrecio(){
            return $this->precio;
        }

        public function getTipo(){
            return $this->tipo;
        }

        public function setPrecio($precio){
            $this->precio = $precio;
        }

        public function setTipo($tipo){
            $this->tipo = $tipo;
        }

        public function setCantidad($cant){
            $this->cantidad = $cant;
        }

        public function setSabor($sabor){
            $this->sabor = $sabor;
        }

        public function getCantidad(){
            return $this->cantidad;
        }

        public function __toString()
        {
            return $this->sabor . ',' . $this->precio . ',' . $this->cantidad . ',' . $this->tipo . PHP_EOL;
        }
    }
?>
