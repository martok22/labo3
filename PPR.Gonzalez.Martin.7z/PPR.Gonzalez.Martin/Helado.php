<?php   
    class Helado implements IVendible{
        private $sabor;
        private $precio;
        private $imagen;

        public function __construct($sab, $prec, $img)
        {
            $this->sabor = $sab;
            $this->precio = $prec;
            $this->imagen = $img;
        }

        public function PrecioMasIva($helado)
        {
            $precioMasIva = $helado->precio + $helado->precio * 21/100;
            $helado->precio = $precioMasIva;
        }

        /*public function __get($name)
        {
            return $this->$name;
        }*/

        public function getSabor(){
            return $this->sabor;
        }

        public function getPrecio(){
            return $this->precio;
        }

        public function getImagen(){
            return $this->imagen;
        }

        public function setPrecio($precio){
            $this->precio = $precio;
        }

        public function setImagen($img){
            $this->imagen = $img;
        }

        public function __toString()
        {
            return $this->sabor . ',' . $this->precio . ',' . $this->imagen . PHP_EOL;
        }
    }
    interface IVendible{
        public function PrecioMasIva($helado);
    }
?>
