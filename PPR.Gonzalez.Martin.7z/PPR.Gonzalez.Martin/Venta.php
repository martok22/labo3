<?php
    require_once("Helado.php");
    class Venta extends Helado{
    
        private $correo;
        public function __construct($sabor, $precio,$cant, $tipo, $correo)
        {
            $this->setCorreo($correo);
            parent::setSabor($sabor);
            parent::setPrecio($precio);
            parent::setCantidad($cant);
            parent::setTipo($tipo);
        }

        public function __toString()
        {
            return trim(parent::__toString()) . ',' . $this->correo . PHP_EOL;
        }

        public function setCorreo($correo){
            $this->correo = $correo;
        }

        public function getCorreo(){
            return $this->correo;
        }
    }
    ?>