var httpReq = new XMLHttpRequest();
var result;
var cargado = false;

function ajaxResultPOST(result) {
    if (result.type != 'error' && (result.type == 'User' || result.type == 'Admin')) {
        guardarEnLStorage(result);
        //location.href='index.html';
        console.log('success');
        location.href = 'index.html';
    }
    if (result.type == 'error' && result.message != null) { // Si el msg de error viene de editarNota
        //location.href='index.html';
        console.log('error: ' + result.message);
        MostrarErrorContraseña();
    }
    else if (result.type == 'error' && result.message == null) {
        MostrarErrorContraseña();
        console.log('error: ' + result.message);
    }
    //if(result.type=='ok') location.href='index.html';         
}
function ajaxResultGET(result) {
    $("#tabla").html(crearTabla(result));
}
function Ajax(metodo, direccion, datos) {
    $.ajax({
        url: direccion,
        type: (metodo == 'POST' ? 'POST' : 'GET'),
        setRequestHeader: '"Content-Type","application/json"',
        data: datos,
        success: function (result) {
            if (this.type == 'POST')
                ajaxResultPOST(result);
            else
                ajaxResultGET(result);
        }
    });
}

function BotonLogin(metodo, direccion) {
    $('#spinar').css('display', 'none');
    Ajax(metodo, direccion);
}

function BotonAgregar() {
    data = getDataFromInput('id', 'nombre', 'legajo', 'materia', 'nota');
    Ajax('POST', 'localhost', data);
}

function BotonEditar(id) {
    data = getDataFromInput('id', 'nombre', 'legajo', 'materia', 'nota');
    Ajax('POST', 'localhost', data);
}

function BotonBorrar(id){
    data = getDataFromInput('id', 'nombre', 'legajo', 'materia', 'nota');
    Ajax('POST', 'localhost', data);
}

function crearTabla(lista) {

    tabla_string = "<thead>" +
        "<th>Id</th>" +
        "<th>Legajo</th>" +
        "<th>Nombre</th>" +
        "<th>Materia</th>" +
        "<th>Nota</th>";

    (localStorage.getItem('type') === 'Admin') ? (tabla_string += "<th></th><th></th></thead>") : "</thead>";
    tabla_string += '<tbody>'
    for (contador = 0, id = contador; contador < lista.length; contador++) {
        if (lista[contador] == undefined) {
            id = contador - 1;
            continue;
        }

        tabla_string += "<tr id=" + "'" + contador + "'" + (parseInt(lista[contador].nota) <= 4 ? " class='menorA4'" : "") + ">";
        tabla_string += "<td>" + lista[contador].id + "</td>";
        tabla_string += "<td>" + lista[contador].legajo + "</td>";
        tabla_string += "<td>" + lista[contador].nombre + "</td>";
        tabla_string += "<td>" + lista[contador].materia + "</td>";
        tabla_string += "<td>" + lista[contador].nota + "</td>";
        if (localStorage.getItem('type') === 'Admin') {
            tabla_string += '<td><button value="Editar" onclick="mostrarPopUp(' + lista[contador].id + ')">Editar</button></td>';
            tabla_string += '<td><button value="Borrar" onclick="ajax("POST","http://localhost:3000/eliminarNota",';
            tabla_string += 'getRowToDelete(' + lista[contador].id + '))">Borrar</button></td></tr></tbody>';
        }
        else {
            tabla_string += "</tr></tr></tbody>";
        }
    }
    return tabla_string;
}


/** Recibe una lista de string con el tag id de cada input.
 *  Retorna una lista JSON con key = nombre del input, value = valor del input
 */

function getDataFromInput(listaDeInputs) {
    let lista = {};
    listaDeInputs.forEach(function (item) {
        lista[item] = $('#' + item).val();
    });
    return lista;
}

function guardarEnLStorage(response) {
    localStorage.setItem("email", $("#email").val());
    localStorage.setItem("type", response.type);
}

function MostrarErrorContraseña() {
    if ($('#password').val() != '1234')
        $('#errorMsg').css('visibility', 'visible');
    else
        $('#errorMsg').css('visibility', 'hidden');
}

function OcultarErrorContraseña() {
    if ($('#errorMsg').className == 'mostrar')
        $('#errorMsg').className = 'oculto';
}
function MostrarSpinner(opcion) {
    let propiedad = '';
    if (opcion === 'mostrar') propiedad = 'block'
    else if (opcion === 'ocultar') propiedad = 'none'
    $('#spinar').css('display', propiedad);
}


