var misenlaces = document.getElementsByTagName("a");
alert(misenlaces);
misenlaces.