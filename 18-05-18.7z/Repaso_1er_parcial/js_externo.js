function getUserData(){
    string = "email=" +document.getElementById('correo').value + "&password=" + document.getElementById('password').value;
    return string;
}
var httpReq = new XMLHttpRequest();
var listaJSON;
var callBack_POST = function(){
    console.log("Llego info del servidor" + httpReq.readyState);

    if(httpReq.readyState==4)
    {
        if(httpReq.status==200)
        {
            listaJSON = JSON.parse(httpReq.responseText);
            console.log(httpReq.responseText);
            objJsonAStorage(listaJSON);
            //document.getElementById("tabla").innerHTML = crearTabla(listaJSON);
        }
        else{            
            alert("error en el servidor");
            console.log(httpReq.responseText);
        }  
    }
}
function ajax(metodo, url, parametro){
    
    if(metodo=='GET'){
        httpReq.onreadystatechange=callBack_GET;
        httpReq.open(metodo,url+'?'+parametro,true);
        httpReq.send();
    }
    else if(metodo=='POST'){
        httpReq.onreadystatechange=callBack_POST;
        httpReq.open(metodo,url,true);
        httpReq.setRequestHeader("Content-type","application/x-www-form-urlencoded");
        httpReq.send(parametro());
    }
    //x-www-form-urlencoded
}

function objJsonAStorage(objeto){
    for(contador=0;contador<objeto.length;contador++){
        localStorage.setItem(contador,objeto[contador]);
    }
}

