<?php
    class Archivo{
        private static $path;
        
        public static function GuardarEnArchivo($objeto){
            if(file_exists("$path")){
                if($pArchivo=fopen("$path","a")){
                    if($escrito = fwrite($pArchivo,"$objeto") > 0){
                        echo "<br>Se cargo el objeto con exito<br>.";
                    }    
                    else{
                        echo "<br> Error al escribir el archivo <br>";
                    }
                }
                if(!fclose($pArchivo)) echo "<br> Error al cerrar el archivo. <br>";
            }else{
                if($pArchivo=fopen("$path","w")){
                    if($escrito = fwrite($pArchivo,$ > 0){
                        echo "<br>Se cargo el cliente con exito<br>.";
                    }    
                    else{
                        echo "<br> Error al escribir el archivo <br>";
                    }
                }
                if(!fclose($pArchivo)) echo "<br> Error al cerrar el archivo. <br>";
            }
        }

        public static function CargarDesdeArchivo($objeto){
            $lista = array();
            if($pArchivo=fopen("$path")){
                $lista = array();
                while(!feof($pArchivo)){
                    $array[] = explode(",",fgets($pArchivo));
                }
            }
            return $lista;
        }
?>