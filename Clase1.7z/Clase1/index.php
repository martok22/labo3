<?php   
    include "./Clases/clase1.php"
    //var_dump($arr2);
    ?>