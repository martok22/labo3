namespace Modelo{
    export class Persona {
        private nombre:string;
    
        constructor(nombre:string){
            this.nombre = nombre;
        }
    }
}

