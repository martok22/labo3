
namespace Modelo{

    export class Alumno extends Persona{
        
        }
}
