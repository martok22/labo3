namespace Modelo{
    export class Funciones{
        public static Agregar(nombre:string, legajo:string, materia:string, nota:number){
        
            
        }
    }
}
