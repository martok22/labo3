namespace Modelo{
    export class Alumno extends Persona{
        private legajo:string;
        private materia:string;
        private nota:number;

        constructor(nombre:string, legajo:string, materia:string, nota:number){
            super(nombre);
        }

        public toJSON(){
            return JSON.parse("{legajo: "+this.legajo+", materia: "+this.materia+", nota: "+this.nota+"}");
        }

        public toString(){

        }
    }
}

