// Tipos
var batman = "Bruce";
var superman = "Clark";
var existe = false;
// Tuplas
var parejaHeroes = [batman, superman];
var villano = ["Lex Lutor", 5, true];
// Arreglos
var aliados = ["Mujer Maravilla", "Acuaman", "San", "Flash"];
//Enumeraciones
var fuerzaHeores;
(function (fuerzaHeores) {
    fuerzaHeores[fuerzaHeores["fuerzaFlash"] = 5] = "fuerzaFlash";
    fuerzaHeores[fuerzaHeores["fuerzaSuperman"] = 100] = "fuerzaSuperman";
    fuerzaHeores[fuerzaHeores["fuerzaBatman"] = 1] = "fuerzaBatman";
    fuerzaHeores[fuerzaHeores["fuerzaAcuaman"] = 0] = "fuerzaAcuaman";
})(fuerzaHeores || (fuerzaHeores = {}));
// Retorno de funciones
function activar_batiseñal() {
    return "activada";
}
function pedir_ayuda() {
    console.log("Auxilio!!!");
}
// Aserciones de Tipo
var poder = "100";
var largoDelPoder = poder.length;
console.log(largoDelPoder);
