

// Agregar todos los archivos en script del html, y ojo el orden (se ejecutan de arriba a abajo)
namespace Modelo{
    function main {
        
    }
}

/*interface Animal{
        hacerRuido();
    }
    
    class Perro{
        private nombre;
    
        public constructor{
            this.nombre = "Jorge";
        }
    }*/

    /*let animal:gato = new gato();
    $('#id').val('lago');*/