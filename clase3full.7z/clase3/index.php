<?php
include("persona.php");
    /*$pArchivo = fopen("archivo.txt","w");
    // append crea archivo si no existe. 

    //$escrito = fwrite($pArchivo,"<br>corriendo"); // fwrite no tira error ni warning ejecutado en modo r
    // fwrite devuelve cant de bytes escritos
    fwrite($pArchivo,"primera linea");
    fwrite($pArchivo,PHP_EOL . "algo");
    //echo $escrito;
    fclose($pArchivo);*/
    
    //$retorno_unlink = unlink("archivo.txt");
    //copy("archivo.txt","../archivo.txt");
    $pArchivo = fopen("archivo.txt","r");
    //$a = fgets($pArchivo);
    $a;
    
    /*while(!feof($pArchivo)){
        $a = $a . fgets($pArchivo) . "<br>"; // fgets devuelve los saltos de linea, pero no se ven en navegador.
    }*/
    //echo $a;
    //$b = fread($pArchivo, filesize("archivo.txt"));
    //echo $b;
    $arr1 = array(array("Jorge","Gimenez",35),array("Juan","Baul",55),array("Lero","Lira",4),array("sana","Zona",22));
    /*foreach($arr1 as $value){
        foreach($value as $sub_value){
            fwrite($pArchivo,"$sub_value, ")
        }
        fwrite($pArchivo,"<br>");
    }**/
    $Lista = array();

    //$contador = 0;
    while(!feof($pArchivo)){
        $persona = explode("-",fgets($pArchivo));
        // explode('-',fgets($pArchivo)fread($pArchivo)); ?? profesor escribio eso
        $Lista[] = $persona;
        //$contador++;
    }
    var_dump($Lista);  
    fclose($pArchivo);
    $pArchivo2 = fopen("archivo3.txt","w");
    fclose($pArchivo2);
    foreach($Lista as $value)
    {
        foreach($value as $sub_value)
        {
            echo $sub_value . "<br>";
        }
    }

    $per1 = new Persona("Jairo","Patiño",3,01);
    $per2 = new Persona("Mora","Patiño",4,02);
    $per3 = new Persona("Albe","Morada",1,03);
    $per4;
    $per5;
    $per6;
    $pArchivo = fopen("archivo3.txt","w");
    $a = fwrite($pArchivo,$per1);
    fclose($pArchivo);
    $pArchivo = fopen("archivo3.txt","r");
    $per7 = (fread($pArchivo,filesize("archivo3.txt")));
    $per7 = (object)$per7;
    var_dump($per7);
    //No se pueden castear strings a objeto ocn (object)
    //No se puede utilizar [0,1..etc] en un objeto para obtener atributos

    //$objeto = (object)$Lista[0];
    //echo $objeto;
    //var_dump($objeto);



    
?>