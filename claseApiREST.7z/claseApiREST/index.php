<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require 'vendor/autoload.php';

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

$app = new \Slim\App(["settings"=>$config]);

//$body = $request->getParsedBody();
//$newResponse = $Response->WithJSON($body,200);
//return $newResponse;

$app->get('/hello/{name}', function (Request $request, Response $response, array $args) {
    $name = $args['name'];
    $response->getBody()->write("Hello, $name");
    return $response;
});

$app->post('/hello', function (Request $request, Response $response) {
    
    $body = $request->getParsedBody();
    $response->getBody()->write("Hello, ".$body['algo']."<br>");
    var_dump($body);
    return $response;
});

$app->post('/datos/', function (Request $request, Response $response) {
    $body = $request->getParsedBody();
    $newResponse = $response->WithJSON($body,200); 
    return $newResponse;
});



$app->run();
?>