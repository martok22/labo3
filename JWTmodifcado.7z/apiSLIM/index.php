<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require 'vendor/autoload.php';

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

$app = new \Slim\App(["settings"=>$config]);

//$body = $request->getParsedBody();
//$newResponse = $Response->WithJSON($body,200);
//return $newResponse;

require_once("C:/xampp/htdocs/jwt/Nuevacarpeta/vendor/autoload.php");
use \Firebase\JWT\JWT;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\BeforeValidException;

$app->get('/hello/{name}', function (Request $request, Response $response, array $args) {
    $name = $args['name'];
    $response->getBody()->write("Hello, $name");
    return $response;
});

$app->post('/hello', function (Request $request, Response $response) {
    
    $body = $request->getParsedBody();
    $response->getBody()->write("Hello, ".$body['algo']."<br>");
    var_dump($body);
    return $response;
});

$app->post('/datos/', function (Request $request, Response $response) {
    $body = $request->getParsedBody();
    $newResponse = $response->WithJSON($body,200); 
    return $newResponse;
});

$app->get('/{token}', function (Request $request, Response $response) {
    $key = "example_key";
    $token = array(
        "iss" => "http://example.org",
        "aud" => "http://example.com",
        "iat" => 1356999524,
        "nbf" => 1357000000
    );
    $tokenExpirado =  array(
        "iss" => "http://example.org",
        "aud" => "http://example.com",
        "iat" => 5555599524,
        "nbf" => 2357000000
    );

   // $jwt = JWT::encode($token, $key);
    //var_dump($jwt);
    $token = $request->getHeader("token");
    var_dump($token);
    try{
        $decoded = JWT::decode($token, $key, array('HS256'));
        var_dump((array)$decoded);
    } catch(ExpiredException $e){
        var_dump($e->getMessage());
    }catch(BeforeValidException $e){
        var_dump($e->getMessage());
    }catch(Exception $e){
        var_dump($e->getMessage());
    }
    //var_dump();
    //echo getcwd();
    //echo $_SERVER['DOCUMENT_ROOT'];
    return $token;
    

});



$app->run();
?>