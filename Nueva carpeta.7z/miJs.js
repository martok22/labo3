var jquery = require("jquery-3.3.1.js");
        $("document").ready(function()
        {
            // alert($("#btn").html("OTRA COSA"));
            alert($('#inombre').val("OTRA COSA"));
        });
        /* para POST {"nombre:Matias"} omitir para get. El default es GET*/
        function hacer(){
            $.ajax({
            url: "http://localhost:3000/personas",
            //data: "{nombre:Matias, edad:33}",
            //type: POST,// POST omitir para get
            success: function(result){
                console.log(result);
            },
        })
        }