function laFuncion(){
    ajax('GET','http://localhost:3000/notas','getUserData');
}
laFuncion();

window.onclick = function(event){
    if (event.target == miPopUp){
        miPopUp.style.display = "none";
    }
}

window.onload = A; 
var miPopUp;
function A(){
    miPopUp = document.getElementById('popUp-container');
    console.log(document.getElementsByTagName('body'));
    console.log(miPopUp);
}

var filaAEditar;
function mostrarPopUp(id){
    miPopUp.style.display = 'block';
    filaAEditar = id;
}

 