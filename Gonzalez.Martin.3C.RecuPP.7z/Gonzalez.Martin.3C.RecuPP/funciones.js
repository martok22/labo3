var httpReq = new XMLHttpRequest();
var listaJSON;
var cargado = false;
        
var callBack_GET = function(){
            console.log("Llego info del servidor" + httpReq.readyState);

            if(httpReq.readyState==4)
            {
                if(httpReq.status==200)
                {
                    listaJSON = JSON.parse(httpReq.responseText);
                    document.getElementById("tabla").innerHTML = crearTabla(listaJSON);
                    
                }
                else{            
                    alert("error en el servidor");
                    console.log(httpReq.responseText);
                }  
            }
        }
        var callBack_POST = function(){
            console.log("Llego info del servidor" + httpReq.readyState);

            if(httpReq.readyState==4)
            {
                if(httpReq.status==200)
                {
                    listaJSON = JSON.parse(httpReq.responseText);

                    if(listaJSON.type!='error' && (listaJSON.type == 'User' || listaJSON.type == 'Admin')){
                        guardarEnLStorage(listaJSON);
                        location.href='index.html';
                    }

                    if(listaJSON.type=='error' && listaJSON.message != null){ // Si el msg de error viene de editarNota
                        location.href='index.html';
                    }
                    else if(listaJSON.type=='error' && listaJSON.message == null){
                        MostrarErrorContraseña();
                        document.getElementById('spinner').style.display = 'none';
                    }
                    
                    if(listaJSON.type=='ok') location.href='index.html';
                }
                else{   
                    alert("error en el servidor");
                    console.log(httpReq.responseText);
                }  
            }
        }


function ajax(metodo, url, parametro){
            
            if(metodo=='GET'){
                httpReq.onreadystatechange = callBack_GET;
                httpReq.open(metodo,url,true);
                httpReq.send();
            }
            else if(metodo=='POST'){
                httpReq.onreadystatechange=callBack_POST;
                httpReq.open(metodo,url,true);
                httpReq.setRequestHeader("Content-Type","application/json");
                httpReq.send(parametro());
            }
}

function crearTabla(lista){
    
    tabla_string =  
                    "<th>Id</th>"+
                    "<th>Legajo</th>"+
                    "<th>Nombre</th>"+
                    "<th>Materia</th>"+
                    "<th>Nota</th>";
    
    (localStorage.getItem('type')==='Admin') ? (tabla_string+="<th></th><th></th>") : "";
    
    for(contador=0, id=contador; contador<lista.length ;contador++){
        if(lista[contador]==undefined) {
            id=contador-1;
            continue;
        }

        tabla_string += "<tr id="+"'"+contador+"'"+(parseInt(lista[contador].nota) <= 4 ? " class='menorA4'" : "")+">";
        tabla_string += "<td>" +lista[contador].id+ "</td>";
        tabla_string += "<td>" +lista[contador].legajo+ "</td>"; 
        tabla_string += "<td>" +lista[contador].nombre+ "</td>";
        tabla_string += "<td>" +lista[contador].materia+ "</td>";
        tabla_string += "<td>" +lista[contador].nota+ "</td>";
        if(localStorage.getItem('type')==='Admin')
        {
            tabla_string += '<td><button value="Editar" onclick="mostrarPopUp('+lista[contador].id+')">Editar</button></td>';
            tabla_string += '<td><button value="Borrar" onclick="ajax("POST","http://localhost:3000/eliminarNota",';
            tabla_string += 'getRowToDelete('+lista[contador].id+'))">Borrar</button></td></tr>';
        }
        else{
            tabla_string += "</tr></tr>";
        } 
    }
    return tabla_string;
}


function getUserData(){
    var correo = document.getElementById("email").value;
    var contraseña = document.getElementById("password").value;
    var datosLogin = {
        email: correo,
        password: contraseña
    }
    return JSON.stringify(datosLogin);
}

function getRowToEdit(){
    var datosEdit = {
        id: filaAEditar,
        legajo: document.getElementById('legajo').value,
        nombre: document.getElementById('nombre').value,
        materia: document.getElementById('materia').value,
        nota: document.getElementById('nota').value
    }
    return JSON.stringify(datosEdit);
}

function getRowToDelete(fila){
    var datosDelete = {
        id: fila,
    }
    return JSON.stringify(datosDelete);
}

function guardarEnLStorage(response){
    localStorage.setItem("email",document.getElementById("email").value);
    localStorage.setItem("type",response.type);
}

function MostrarErrorContraseña(){
    if(document.getElementById('password').value != '1234')
        document.getElementById('errorMsg').className = 'mostrar';
    else
        document.getElementById('errorMsg').className = 'oculto';
}

function OcultarErrorContraseña(){
    if(document.getElementById('errorMsg').className == 'mostrar')
        document.getElementById('errorMsg').className = 'oculto';
}

function MostrarSpinner(){
    document.getElementById('spinner').style.display = 'block';
}
