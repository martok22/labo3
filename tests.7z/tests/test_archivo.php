<?php
    echo $_FILES['archivo']['name'] . "<br>";
    echo $_FILES['archivo']['tmp_name'] . "<br>";
    echo $_FILES['archivo']['size'] . "<br>";
    echo $_FILES['archivo']['type'] . "<br>";
    echo $_FILES['archivo']['error'] . "<br>";

    echo pathinfo($_FILES['archivo']['name'],PATHINFO_EXTENSION) . "<br>";
    echo pathinfo($_FILES['archivo']['name'],PATHINFO_BASENAME) . "<br>";
    echo pathinfo($_FILES['archivo']['name'],PATHINFO_DIRNAME) . "<br>";
    echo pathinfo($_FILES['archivo']['name'],PATHINFO_FILENAME);
    ?>