<?php
    class Prueba{
        public $algo = 3;
    }

    $string = 'Prueba' . date('d_m_Y');
    //$objeto = new $string();
    echo $string;
    ?>