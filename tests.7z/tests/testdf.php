<?php
    require_once "Helado.php";
    function cmp($a, $b) {
        if ($a->getPrecio() == $b->getPrecio()) {
            return 0;
        }
        return ($a->getPrecio() < $b->getPrecio()) ? 1 : -1; // mayor a menor
    }

    // Array to be sorted
    $helado1 = new Helado("rojo",13,"algo");
    $helado2 = new Helado("cereza",14,"algo");
    $helado3 = new Helado("amarillo",-1,"algo");
    $array = array('unObj' => $helado1, 'b' => $helado2, 'c' => $helado3);
    print_r($array);
    uasort($array, 'cmp');
    print_r($array);

    ?>