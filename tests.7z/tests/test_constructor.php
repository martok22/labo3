<?php
    class algo{
        public $primer;
        public $tercero;
        public $segundo;

        public function __construct($prim, $seg, $tercero=null){
            $this->primer=$prim;
            $this->segundo = $seg;
            if($tercero!="" && $tercero) $this->tercero=$tercero;
        }
    }

    $al = new algo(1,2);
    $al2 = new algo(1,2,3);
    echo $al2->primer . $al2->tercero;
    ?>