<?php
    $miString = "algo";
    $stringPHPEOL = PHP_EOL;
    $array0 = count_chars($miString,0);
    $array1 = count_chars($miString,1);
    $array2 = count_chars($miString,2);
    $array3 = count_chars($miString,3);
    $array4 = count_chars($miString,4);
    $retorno = count_chars($stringPHPEOL,3);
    echo $retorno;
    var_dump($array0);
    echo "<br><br>";
    var_dump($array1);
    echo "<br><br>";
    var_dump($array2);
    echo "<br><br>";
    var_dump($array3);
    echo "<br><br>";
    var_dump($array4);
    echo "<br><br>";
    ?>