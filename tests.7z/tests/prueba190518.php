<?php

$var = is_uploaded_file("heladosImagenes/dulceDeLeche1526398676.jpg");
//echo $var;
//echo true;
$varotra = false;
$varsegunda = true;
$vartercera = true;
echo $varotra;
echo $varsegunda;
echo $vartercera;
?>