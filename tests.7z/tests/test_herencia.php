<?php
    class miClase{
        private $atributoPrivado;
        public $atributoPublico;
        protected $clasePadre;
        public static $atributoPublica;

        public function __construct($atrPriv,$atrProt,$atrPub)
        {
            $this->atributoPrivado = $atrPriv;
            $this->clasePadre = $atrProt;
            $this->atributoPublico = $atrPub;
        }
        public function __get($name)
        {
            return $this->$name;
        }

        public function __set($name, $value)
        {
            $this->$name = $value;
        }
    }

     class otraClase extends miClase{
        private $atributoPrivado;
        public $atributoPublico;
        protected $atributoProtegido;

        public function __construct($atrPriv,$atrProt,$atrPub)
        {
            $this->atributoPrivado = $atrPriv;
            $this->atributoProtegido = $atrProt;
            $this->atributoPublico = $atrPub;
            //$this->clasePadre = 15;
            miCLase::$atributoPublica = 18;
            
        }

        public function __get($name)
        {
            return $this->$name;
        }
        

    }

    $per1 = new miClase(1,2,3);
    echo "<br> " . $per1->atributoPublico;
    echo "<br> " . $per1->clasePadre;
    echo "<br> " . $per1->atributoPrivado;
    $per2 = new otraClase(4,5,6);
    echo "<br> " . $per2->atributoPublico;
    echo "<br> " . $per2->atributoProtegido;
    echo "<br> " . $per2->atributoPrivado;
    $per1->clasePadre = 10;
    echo "<br> " . $per1->clasePadre;
    echo "<br> " . $per2->clasePadre;
    echo "<br> " . $per2::$atributoPublica;

?>