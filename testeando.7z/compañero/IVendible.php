<?php

    interface IVendible {

        function PreciosMasIVA();
    }
?>