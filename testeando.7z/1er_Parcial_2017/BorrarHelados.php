<?php
    if(isset($_GET['sabor'])){
        if($pArchivo=fopen("./heladosArchivo/helados.txt","r")){
            $array = array();
            while(!feof($pArchivo)){
                $array[] = explode(",",fgets($pArchivo,filesize($pArchivo)));
            }
            foreach($array as $value){
                if ($value->sabor == $_GET['sabor']) echo "El sabor está en la lista <br>";
                else
                    echo "El sabor no está en la lista <br>";
            }
            fclose($pArchivo);
        }
    }
    if(isset($_POST['sabor']) && $_POST['queDeboHacer'] == 'borrar'){
        
    }
    ?>

    