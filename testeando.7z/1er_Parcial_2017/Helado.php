<?php   
    class Helado implements IVendible{
        private $sabor;
        private $precio;

        public function __construct($sab, $prec)
        {
            $this->sabor = $sab;
            $this->precio = $prec;
        }

        public static function RetornarArrayHelados(){
            $array = array();
            $hel1 = new Helado("chocolate","4");
            $hel2 = new Helado("dulce_leche","3");
            $hel3 = new Helado("coco","2");
            $hel4 = new Helado("americana","5");
            $hel5 = new Helado("frutilla","6");
            array_push($array,$hel1);
            array_push($array,$hel2);
            array_push($array,$hel3);
            array_push($array,$hel4);
            array_push($array,$hel5);
            return $array;
        }

        public static function MostrarHeladosGuardados(){
            $array_helados = array();
            if($pArchivo=fopen("./heladosArchivo/helados.txt","r")){
                $array_helados[] = explode(",",fgets($pArchivo,filesize("./heladosArchivo/helados.txt")));
                foreach($array_helados as $value){
                    printf("El sabor es %s y el precio es %s <br>",$value[0],$value[1]);
                }
            }
            if(fclose($pArchivo)) echo "<br> Se cerro el archivo";
        }

        public function PrecioMasIva($helado)
        {
            $precioMasIva = $helado->precio + $helado->precio * 21/100;
            $helado->precio = $precioMasIva;
        }

        public function __get($name)
        {
            return $this->$name;
        }
    }
    interface IVendible{
        public function PrecioMasIva($helado);
    }
?>
