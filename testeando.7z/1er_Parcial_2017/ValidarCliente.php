<?php
    include("Cliente.php");
    $array = array();
    $line;
    if($pArchivo=fopen("archivo.txt","r")){
        while($line = fgets($pArchivo)){
            $array[] = explode(",",$line);
        }
        if(fclose($pArchivo)) echo "<br> Se cerró el archivo correctamente. <br>";
        else
            echo "<br> Error al cerrar archivo. <br>";
    }
    else
        echo "<br> Error al abrir el archivo. <br>";
    foreach($array as $value){
        if($value[1] == $_POST['correo'] && $value[2] == ($_POST['clave'] . PHP_EOL))
        {
            echo "<br>. Usuario Logeado. <br>";
            break;
        }
        else{
            echo "<br>. Usuario inexistente. <br>";
            var_dump($value[0],$value[1],$value[2]);
        }
            
    }
?>