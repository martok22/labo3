<?php
    include("Cliente.php");
    $cliente = new Cliente($_GET['nombre'],$_GET['correo'],$_GET['clave']);
    $cliente->GuardarEnArchivo("archivo.txt",$cliente);
?>