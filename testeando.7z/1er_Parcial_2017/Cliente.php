<?php
    class Cliente{
        private $nombre;
        private $correo;
        private $clave;

        public function __construct($nombre, $correo, $clave)
        {
            $this->nombre = $nombre;
            $this->correo = $correo;
            $this->clave = $clave;
        }

        public function __toString()
        {
            return $this->nombre . "," . $this->correo . "," . $this->clave . PHP_EOL;
        }

        public static function GuardarEnArchivo($path,$cliente){
            if($pArchivo = fopen($path,"a")){
                $escrito = fwrite($pArchivo,$cliente->__toString());
                if($escrito == strlen($cliente->__toString()))
                    echo "<br>Se han escrito " . $escrito . " caracteres.<br>";
                    else
                        "<br> Error al escribir el archivo. <br>";
            
            if(fclose($pArchivo)) echo "<br> Se cerro el archivo correctamente. <br>";
            else
                echo "<br> Error al cerrar el archivo. <br>";
            }
            else
                echo "<br> Error al abrir el archivo. <br>";
        }
    }
    ?>