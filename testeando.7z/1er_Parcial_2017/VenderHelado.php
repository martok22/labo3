<?php
include("Helado.php");
$lista_helados = (new Helado())->RetornarArrayHelados();
foreach($lista_helados as $value){
    if($value[0] == $_GET['sabor']){
        $hel1 = new Helado($value[0],$value[1]);
        echo "El precio del helado es " . $hel1->PrecioMasIva($hel1);
    }
    else
        echo "No tenemos ese gusto :(";    
}
?>