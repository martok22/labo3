<?php
    include("Helado.php");
    $helado = new Helado($_POST['sabor'],$_POST['precio']);
    echo $helado->sabor;
    $nombre_img = $_POST['sabor'] . time() . '.jpg';
    if(move_uploaded_file($_FILES['archivo']['tmp_name'],"./heladosImagenes/$nombre_img")) echo "Se movio la imagen";
    if($pArchivo=fopen("./heladosArchivo/helados.txt","w")){
        $frase = $helado->sabor . "," . $helado->precio . "," . $nombre_img . PHP_EOL;
        $escrito = fwrite($pArchivo,$frase);
    }
    if(fclose($pArchivo)) echo "Se cerro el archivo sin prob";
    ?>