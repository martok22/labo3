<?php
    include("Helado.php");
    Helado::MostrarHeladosGuardados();
?>