<?php

class Helado
{
    public $sabor;
    public $precio;
    public $cantidad;
    public $tipo;

    public function MostrarDatos()
    {
            return $this->sabor." - ".$this->precio." - ".$this->cantidad ." - ".$this->tipo;
    }
    
    public static function TraerUnHeladocantidadParamNombreArray($sabor, $cantidad)
    {    
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT sabor AS sabor, precio AS precio, "
                                                        . "cantidad AS cantidad FROM Helados WHERE sabor = :sabor "
                                                        . "AND cantidad= :cantidad");
        
        $consulta->execute(array(":sabor" => $sabor, ":cantidad" => $cantidad));
        
        $HeladoBuscado = $consulta->fetchObject('Helado');
        
        return $HeladoBuscado; 
    }
    
    public function InsertarElHeladoParametros()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        
        $consulta =$objetoAccesoDato->RetornarConsulta("INSERT INTO Helados (sabor, precio, cantidad)"
                                                    . "VALUES(:sabor, :precio, :cantidad)");
        
        $consulta->bindValue(':sabor', $this->sabor, PDO::PARAM_INT);
        $consulta->bindValue(':cantidad', $this->cantidad, PDO::PARAM_INT);
        $consulta->bindValue(':precio', $this->precio, PDO::PARAM_STR);

        $consulta->execute();   

    }
    
    public static function ModificarHelado($id, $sabor, $cantidad, $precio)
    {

        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        
        $consulta =$objetoAccesoDato->RetornarConsulta("UPDATE Helados SET sabor = :sabor, precio = :precio, 
                                                        cantidad = :cantidad WHERE id = :id");
        
        $consulta->bindValue(':id', $id, PDO::PARAM_INT);
        $consulta->bindValue(':sabor', $sabor, PDO::PARAM_INT);
        $consulta->bindValue(':cantidad', $cantidad, PDO::PARAM_INT);
        $consulta->bindValue(':precio', $precio, PDO::PARAM_STR);

        return $consulta->execute();

    }

    public static function EliminarHelado($id)
    {

        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        
        $consulta =$objetoAccesoDato->RetornarConsulta("DELETE FROM Helados WHERE id = :id");
        
        $consulta->bindValue(':id', $id, PDO::PARAM_INT);

        return $consulta->execute();

    }
    
}