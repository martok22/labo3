<?php
include("persona.php");
$per1;
if(!empty($_POST)) 
{
    $per1 = new Persona($_POST['nombre'],$_POST['apellido'],$_POST['legajo'],$_POST['edad']);
    $per1->Cargar();
    if(isset($_POST['modificar'])){
        $per1->Modificar();
    }
    elseif(isset($_POST['guardar'])){
        $per1->Guardar();
    }
    elseif(isset($_POST['borrar'])){
        $per1->Borrar();
    }
}
echo "<br><br><a href='formulario_completo.html'>VolverA</a>";



/*
switch($_POST){
    
}*/
?>