<?php
    class Persona{
        private $nombre;
        private $apellido;
        private $edad;
        private $legajo;
        private $Lista;

        public function __construct($nom, $ape, $ed,$leg){
            $this->nombre = $nom;
            $this->apellido = $ape;
            $this->edad = $ed;
            $this->legajo = $leg;
            $this->Lista = array();
            
        }

        public function __get($prop){
            return $this->$prop;
        }

        public function __set($prop, $value){
            $this->$prop = $value;
        }

        public function __toString(){
            $frase = $this->nombre . "-" . $this->apellido . "-" . $this->edad . "-" . $this->legajo . PHP_EOL;
            return $frase;
        }
        // metodos cargar, modificar

        public function Cargar(){
            $pArchivo = fopen("archivo.txt","r");
            while(!feof($pArchivo))
            {
                $persona = explode("-",fgets($pArchivo));
                $this->Lista[] = $persona;
            }
            fclose($pArchivo);
        }
        // Tiene que modificar atributos, y cuando se agrega imagen, copiar la imagen vieja a una carpeta de backup, subir la nueva y 
        // escribirla en el archivo txt
        public function Modificar(){
            foreach($this->Lista as $value)
            {
                echo $value[2];
                if($value[2] == $this->legajo){
                    $value[0] = $this->nombre;
                    $value[1] = $this->apellido;
                    $value[3] = $this->edad;
                }    
            }
        }

        public function Borrar(){
            // Lees archivo, cargas personas en array, no grabas las que queres borrar
            foreach($this->Lista as $value)
            {
                if($value[0] == $_POST['legajo']){
                    $value = NULL;
                }    
            }
        }

        public function Guardar(){
            if(!empty($this->Lista)){
                $pArchivo = fopen("archivo.txt","a");
                fwrite($pArchivo,"$this");
                fclose($pArchivo);    
            }
                
        }
    }
?>