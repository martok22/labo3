<?php
include("../clase3/persona.php");
var_dump($_POST);
unset($_GET);
if(isset($_GET)) echo "Esta seteada";
echo "<br><br><a href='index.php'>VolverA</a>";

if(isset($_POST['modificar'])){
    //
}
elseif(isset($_POST['cargar'])){

}
else{

}

$per1 = new Persona("ar","br",3,4);
$per1->Modificar();
/*
switch($_POST){
    
}*/
?>