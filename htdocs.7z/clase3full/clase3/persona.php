<?php
    class Persona{
        private $nombre;
        private $apellido;
        private $edad;
        private $legajo;

        public function __construct($nom, $ape, $ed,$leg){
            $this->nombre = $nom;
            $this->apellido = $ape;
            $this->edad = $ed;
            $this->legajo = $leg;
            
        }

        public function __get($prop){
            return $this->$prop;
        }

        public function __set($prop, $value){
            $this->$prop = $value;
        }

        public function __toString(){
            $frase = $this->nombre . "-" . $this->apellido . "-" . $this->edad . "-" . $this->legajo;
            return $frase;
        }
        // metodos cargar, modificar
        public function Modificar(){
            $pArchivo = fopen("archivo.txt","w");
            $Lista = array();
            //rewind($pArchivo);
            $persona = "Jorge-Gimenez-3-4";
            fwrite($pArchivo,$persona);
            $persona = "Jairo-Patiño-2-3";
            fwrite($pArchivo,$persona);
            fclose($pArchivo);
            $pArchivo = fopen("archivo.txt","r");

            while(!feof($pArchivo))
            {
                echo "en el while";
                $persona = explode("-",fgets($pArchivo));
                $Lista[] = $persona;
            }
            foreach($Lista as $value){
                var_dump($value);    
            }
            fclose($pArchivo);
        }

        public function Borrar(){
            // Lees archivo, cargas personas en array, no grabas las que queres borrar
            $pArchivo = fopen("archivo4.txt","r");
            fread($pArchivo);
        }

        public function Guardar(){
            $pArchivo = fopen("archivo4.txt","w");
            fwrite($pArchivo,$this);
            fclose($pArchivo);
        }
    }
?>