<?php
    class Persona{
        private $nombre;
        private $apellido;
        private $edad;
        private $legajo;

        public function __construct($nom, $ape, $ed,$leg){
            $this->nombre = $nom;
            $this->apellido = $ape;
            $this->edad = $ed;
            $this->legajo = $leg;
            
        }

        public function __get($prop){
            return $this->$prop;
        }

        public function __set($prop, $value){
            $this->$prop = $value;
        }

        public function __toString(){
            $frase = $this->nombre . "-" . $this->apellido . "-" . $this->edad . "-" . $this->legajo;
            return $frase;
        }
    }
?>