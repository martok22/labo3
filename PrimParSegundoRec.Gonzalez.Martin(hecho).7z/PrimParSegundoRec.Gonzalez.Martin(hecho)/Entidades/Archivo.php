<?php
    class Archivo{

        /** Instancia un objeto desde un array. Si el array posee imagen en el último valor, setea su nombre
         * en el objeto.
         * @ Array de parametros a instanciar
         * @ Nombre de la clase a instanciar
         * Exito: retorna el objeto creado. 
         * Fracaso: null si el nombre de clase no coincide, o si el array tiene tamaño
         * distinto a la cantidad de variables del constructor.
         */ 
        public static function ObtenerObjeto($linea,$nombreClase){
            if(count($linea)==4 || count($linea)==5){
                if($nombreClase=='Helado'){
                    $helado = new Helado($linea[0],$linea[1],$linea[2],trim($linea[3]));
                    if(count($linea)==5) $helado->setImagen(trim($linea[4]));
                    return $helado;
                }
                else if($nombreClase=='Venta'){
                    $venta = new Venta($linea[0],$linea[1],$linea[2],trim($linea[3]));
                    if(count($linea)==5) $venta->setImagen(trim($linea[4]));
                    return $venta;
                }
                else if($nombreClase=='Alumno'){
                    $venta = new Alumno($linea[0],$linea[1],$linea[2],trim($linea[3]));
                    return $venta;
                }
            }
            else 
                return null;
        }

        /** Serializa un objeto en un archivo de texto utilizando su método ToString.
         * @ Path Donde se encuentra el archivo.
         * @ Objeto a serializar. Debe poseer un método ToString.
         * @ Modo de escritura.
         * 
         */
        public static function GuardarObjeto($path, $objeto, $modo){
            if($pArchivo = fopen($path,$modo)){
                $escrito = fwrite($pArchivo,$objeto);
                if($escrito != strlen($objeto))
                    echo "<br> Error al escribir el archivo. <br>";
            if(!fclose($pArchivo))
                echo "<br> Error al cerrar el archivo. <br>";
            }
            else
                echo "<br> Error al abrir el archivo. <br>";
        }
        /** Serializa una lista de objetos en un archivo de texto. Utiliza metodo ToString del objeto.
         * @ Path Donde se encuentra el archivo.
         * @ Array de objetos a serializar. Cada objeto debe poseer un método ToString.
         * @ Modo de escritura.
         */
        public static function GuardarArray($path, $array, $modo){
            if($pArchivo = fopen($path,$modo)){
                foreach($array as $value){
                    $escrito = fwrite($pArchivo,$value);
                    if($escrito != strlen($value))
                            "<br> Error al escribir el archivo. <br>";
                }    
                if(!fclose($pArchivo))
                    echo "<br> Error al cerrar el archivo. <br>";
            }
            else
                echo "<br> Error al abrir el archivo. <br>";
        }
        /** Lee un archivo de texto que posea objetos serializados por linea y retorna una array de 
         * objetos.
         * @ Path donde se encuentra el archivo.
         * @ Nombre de la clase del objeto a deserializar.
         * Retorna un array de objetos, o array vacío si el tamaño del archivo es 0 o si hubo error al abrir
         * el archivo.
         * 
         */ 
        public static function Leer($path,$nombreClase){
            $linea = array();
            $arrayDeObjetos = array();
            
            if(filesize($path) > 0)
            {
                if($pArchivo=fopen($path,"r")){
                    while(!feof($pArchivo)){
                        $linea = explode("-",fgets($pArchivo,filesize($path)));
                        if(count($linea)>=1){
                            $objeto = Archivo::ObtenerObjeto($linea,$nombreClase);
                            if($objeto!=null)
                                array_push($arrayDeObjetos,$objeto);
                        }
                    }
                    if(!fclose($pArchivo))
                        echo "<br> Error al cerrar el archivo. <br>";
                }   
                else
                    echo "<br> Error al abrir el archivo. <br>";
            }
            return $arrayDeObjetos;
        }

        /** Filtra un array si el metodo pasado como segundo parametro
         *  coincide con el tercer parametro.
         */
        public static function Filtrar($array,$nombreMetodo,$parametro){
        
            return array_filter($array,function($a) use ($nombreMetodo,$parametro){
                return ($a->$nombreMetodo() === $parametro);
            });   
        }
        
        // Retorna array de nombre de archivos en un directorio, o false si no es directorio.
        public static function MostrarImagenes($path,$tituloImagenes){
            $tabla = "<table border=1 style='width:50%;'>" . 
                        "<thead>".
                            "<th>".$tituloImagenes."</th>".
                            "<th>Nombre</th>".
                        "</thead>".
                        "<tbody>";
            
            $imagenes = scandir($path);
            array_splice($imagenes,0,2); // EXTRAIGO DIRS '.' Y '..'
            foreach($imagenes as $imagen){
                $tabla.= "<tr ><td><img src='".$path.$imagen."' style='width:100%; height:50%;'></td>";
                $tabla.= "<td>$imagen</td></tr>";
            }
            $tabla.=    "</tbody>".
                     "</table>";
            return $tabla;
        }
    }
    ?>