<?php 
    class Alumno{
        private $mail;
        private $nombre;
        private $apellido;
        private $clave;

        public function __construct($mail, $nombre, $apellido, $clave)
        {
            $this->SetMail($mail);
            $this->SetNombre($nombre);
            $this->SetClave($clave);
            $this->SetApellido($apellido);
        }

        public function GetMail(){
            return $this->mail;
        }

        public function GetNombre(){
            return $this->nombre;
        }

        public function GetClave(){
            return $this->clave;
        }

        public function GetApellido(){
            return $this->apellido;
        }

        public function SetNombre($nombre){
            $this->nombre = $nombre;
        }

        public function SetClave($clave){
            $this->clave = strtolower($clave);
        }

        public function SetApellido($apellido){
            $this->apellido = $apellido;
        }

        public function SetMail($mail){
            $this->mail = strtolower($mail);
        }

        public function __toString()
        {
            return $this->mail . '-' . $this->nombre . '-' . $this->apellido . '-' . $this->clave . PHP_EOL;
        }
        // RETORNA TRUE SI LA CLAVE DEL OBJ COINCIDE CON EL PARAMETRO PASADO
        public function BuscarPorClave($parametro){
            return strtolower($this->GetClave()) === strtolower($parametro);
        }
        // RETORNA TRUE SI EL MAIL DEL OBJ COINCIDE CON EL PARAMETRO PASADO
        public function BuscarPorMail($parametro){
            return strtolower($this->GetMail()) === strtolower($parametro);
        }

        public function MostrarAlumno(){
            print("\n" . "mail:". $this->GetMail() .
                  "\n" . "clave:". $this->GetClave() .
                  "\n" . "apellido:". $this->GetApellido() .
                  "\n" . "nombre:" . $this->GetNombre());
        }

        public static function MostrarAlumnos()
        {
            $listaVentas = Archivo::Leer(rutaVentas,'Venta');
            $tabla = "<table><thead>".
                        "<tr>".
                            "<td>Mail</td>".
                            "<td>Clave</td>".
                            "<td>Apellido</td>".
                            "<td>Nombre</td>".
                        "</tr>".
                        "</thead>".
                        "<tbody>";
            foreach ($listaVentas as $venta) {
                $tabla .= "<tr><td>".$venta->GetMail()."</td>";
                $tabla .= "<td>".$venta->GetClave()."</td>";
                $tabla .= "<td>".$venta->GetApellido()."</td>";
                $tabla .= "<td>".$venta->GetNombre()."</td>";
            }
            $tabla .= "</tbody></tabla>";
            return $tabla;
        }
    }
?>
        