<?php   
    class Helado{
        private $sabor;
        private $precio;
        private $cantidad;
        private $tipo;
        private $imagen='';

        public function __construct($sab, $prec, $cant, $tipo)
        {
            $this->SetSabor($sab);
            $this->SetPrecio($prec);
            $this->SetTipo($tipo);
            $this->SetCantidad($cant);
        }

        public function GetSabor(){
            return $this->sabor;
        }

        public function GetPrecio(){
            return $this->precio;
        }

        public function GetTipo(){
            return $this->tipo;
        }

        public function GetCantidad(){
            return $this->cantidad;
        }

        public function SetPrecio($precio){
            $this->precio = $precio;
        }

        public function SetTipo($tipo){
            $this->tipo = strtolower($tipo);
        }

        public function SetCantidad($cant){
            $this->cantidad = $cant;
        }

        public function SetSabor($sabor){
            $this->sabor = strtolower($sabor);
        }



        public function __toString()
        {
            return $this->sabor . '-' . $this->precio . '-' . $this->cantidad . '-' . $this->tipo . ($this->imagen!=null ? '-'.$this->imagen : "") . PHP_EOL;
        }

        public function SetImagen($imagen){
            $this->imagen = $imagen;
        }

        public function GetImagen(){
            return $this->imagen;
        }

        // GENERA NOMBRE.EXTESNION
        public function GenerarNombreImg($imagen_FILES){
            $nombreImg = '';
            $extension = pathinfo($_FILES[$imagen_FILES]['name'],PATHINFO_EXTENSION);
            $nombreImg = $this->GetSabor() . date("dmy") . '.' . $extension; 
            return $nombreImg;
        }

        // GUARDA IMG EN CARPETA
        public function GuardarImagen($imagen_FILES,$ruta){
            return move_uploaded_file($_FILES[$imagen_FILES]['tmp_name'],$ruta.$this->imagen);
        }
        
        public function MoverImagenBackup($rutaImg,$rutaImgBackup){
            return (copy($rutaImg.$this->imagen,$rutaImgBackup.$this->imagen) && 
                    unlink($rutaImg.$this->imagen));
        }
        
        public function BuscarPorTipo($parametro){
            return strtolower($this->GetTipo()) === strtolower($parametro);
        }

        public function BuscarPorSabor($parametro){
            return strtolower($this->GetSabor()) === strtolower($parametro);
        }

        public function MostrarHelado(){
            print("\n" . "sabor:". $this->GetSabor() .
                  "\n" . "tipo:". $this->GetTipo() .
                  "\n" . "cantidad:". $this->GetCantidad() .
                  "\n" . "precio:" . $this->GetPrecio());
        }

        public static function MostrarHelados($listaHelados)
        {
            $tabla = "<table><thead>".
                        "<tr>".
                            "<td>Sabor</td>".
                            "<td>Tipo</td>".
                            "<td>Cantidad</td>".
                            "<td>Precio</td>".
                            "<td>Imagen</td>".
                        "</tr>".
                        "</thead>".
                        "<tbody>";
            foreach ($listaVentas as $venta) {
                $tabla .= "<tr><td>".$venta->GetSabor()."</td>";
                $tabla .= "<td>".$venta->GetTipo()."</td>";
                $tabla .= "<td>".$venta->GetCantidad()."</td>";
                $tabla .= "<td>".$venta->GetPrecio()."</td>";
                $tabla .= "<td><img src='".rutaVentasImagenes.$this->imagen>"' style='height:25%; width:25%' ></td></tr>";
            }
            $tabla .= "</tbody></tabla>";
            return $tabla;
        }

        
    }
?>
