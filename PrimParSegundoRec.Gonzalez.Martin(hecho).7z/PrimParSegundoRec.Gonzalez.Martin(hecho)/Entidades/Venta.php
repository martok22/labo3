<?php

    class Venta{

        private $mail;
        private $sabor;
        private $cantidad;
        private $tipo;
        private $imagen='';

        public function __construct($sabor, $cant, $tipo, $mail)
        {
            $this->SetSabor($sabor);
            $this->SetCantidad($cant);
            $this->SetTipo($tipo);
            $this->SetMail($mail);
        }

        public function __toString()
        {
            return $this->sabor . '-' . $this->cantidad . '-' . $this->tipo . '-' . $this->mail . ($this->imagen!='' ? '-'.$this->imagen : '') . PHP_EOL;
        }

        public function GetSabor(){
            return $this->sabor;
        }

        public function GetTipo(){
            return $this->tipo;
        }

        public function SetTipo($tipo){
            $this->tipo = strtolower($tipo);
        }

        public function SetCantidad($cant){
            $this->cantidad = strtolower($cant);
        }

        public function SetSabor($sabor){
            $this->sabor = strtolower($sabor);
        }

        public function GetCantidad(){
            return $this->cantidad;
        }

        public function SetImagen($imagen){
            $this->imagen = $imagen;
        }
        
        public function GetImagen(){
            return $this->imagen;
        }

        public function GetMail(){
            return $this->mail;
        }

        public function SetMail($mail){
            $this->mail = strtolower($mail);
        }

        // Genera nombre y extension. imagen_FILES es la venta de $_POST
        public function GenerarNombreImg($imagen_FILES){
            $nombreImg = '';
            $extension = pathinfo($_FILES[$imagen_FILES]['name'],PATHINFO_EXTENSION);
            $nombreImg = $this->GetSabor() . date("dmy") . '.' . $extension; 
            return $nombreImg;
        }

        // Guarda imagen en carpeta. imagen_FILES es la venta de $_POST. 
        public function GuardarImagen($imagen_FILES,$ruta){
            return move_uploaded_file($_FILES[$imagen_FILES]['tmp_name'],$ruta.$this->imagen);
        }
        
        public function MoverImagenBackup($rutaImg,$rutaImgBackup){
            return (copy($rutaImg.$this->imagen,$rutaImgBackup.$this->imagen) && 
                    unlink($rutaImg.$this->imagen));
        }

        public function MostrarVenta(){
            print("\n" . "sabor:". $this->GetSabor() .
                  "\n" . "tipo:". $this->GetTipo() .
                  "\n" . "cantidad:". $this->GetCantidad() .
                  "\n" . "mail:" . $this->GetMail());
        }

        public static function MostrarVentas($listaVentas)
        {
            $tabla = "<table><thead>".
                        "<tr>".
                            "<td>Sabor</td>".
                            "<td>Tipo</td>".
                            "<td>Cantidad</td>".
                            "<td>Mail</td>".
                            "<td>Imagen</td>".
                        "</tr>".
                        "</thead>".
                        "<tbody>";
            foreach ($listaVentas as $venta) {
                $tabla .= "<tr><td>".$venta->GetSabor()."</td>";
                $tabla .= "<td>".$venta->GetTipo()."</td>";
                $tabla .= "<td>".$venta->GetCantidad()."</td>";
                $tabla .= "<td>".$venta->GetMail()."</td>";
                $tabla .= "<td><img style='height:10%;width:10%'  src='".rutaVentasImagenes.$venta->imagen>"'></td></tr>";
            }
            $tabla .= "</tbody></tabla>";
            return $tabla;
        }
    }
    ?>