<?php
require_once("Entidades/Helado.php");
require_once("Entidades/Archivo.php");
require_once("Entidades/Venta.php");
require_once("Entidades/Alumno.php");

const rutaHeladosImagenes = "./heladosImagenes/";
const rutaBackupImagenes = "./heladosImagenesBackup/";
const rutaHelados = "./heladosArchivo/Helados.txt";
const rutaVentas = "./ventasArchivo/Ventas.txt";
const rutaVentasImagenes = "./ventasImagenes/";
const rutaAlumnos = "./alumnosArchivo/Alumnos.txt";


switch ($_REQUEST['accion']) {

    case 'Alumno':
    if(isset($_GET['nombre'], $_GET['apellido'], $_GET['mail'], $_GET['clave'])){
        $listaAlumnos = Archivo::Leer(rutaAlumnos,'Alumno');
        $repetido = false;
        foreach ($listaAlumnos as $alumno) {
            // VERIFICO NO DUPLICADOS
            if ($alumno->BuscarPorMail($_GET['mail']))
            {
                echo "<br> Ese mail ya existe <br>";
                $repetido = true;
                break;
            }
        }
        if(!$repetido){
            $alumno = new Alumno($_GET['mail'], $_GET['nombre'], $_GET['apellido'], $_GET['clave']);
            array_push($listaAlumnos,$alumno);
            Archivo::GuardarArray(rutaAlumnos,$listaAlumnos,'w');
            echo "Alumno cargado con exito.";
        }
    }
    break;
   
    case 'loginUsuario':

        $listaAlumnos = Archivo::Leer(rutaHelados, 'Alumno');
        $hay = false;
        foreach ($listaAlumnos as $alumno) {
            if ($alumno->BuscarPorMail($_POST['mail']) && $alumno->BuscarPorClave($_POST['clave'])) {
                echo "<br> Bienvenido. <br>";
                $hay = true;
                break;
            }
        }
        if (!$hay) echo "<br> Usuario o clave invalido. <br>";
        break;

    case 'heladoCarga':

        if (isset($_POST['sabor'], $_POST['precio'], $_POST['tipo'], $_POST['cantidad'])) {
            $listaHelados = Archivo::Leer(rutaHelados, 'Helado');
            //ME FIJO SI YA HAY
            $repetido = false;
            foreach ($listaHelados as $helado) {

                if ($helado->BuscarPorSabor($_POST['sabor']) && $helado->BuscarPorTipo($_POST['tipo']))
                {
                    echo "<br> Ese gusto ya existe <br>";
                    $repetido = true;
                    break;
                }
            }
            if(!$repetido){
                
                $helado = new Helado($_POST['sabor'], $_POST['precio'], $_POST['cantidad'], $_POST['tipo']);
                
                if (isset($_FILES['imagen'])) {
                    $helado->SetImagen($helado->GenerarNombreImg('imagen'));
                    if ($helado->GuardarImagen('imagen',rutaHeladosImagenes)) {
                        echo "Se ha guardado el helado. Datos: ";
                        $helado->MostrarHelado();
                    } 

                    array_push($listaHelados,$helado);
                    Archivo::GuardarArray(rutaHelados,$listaHelados,'w');
                }
            }
        }

        break;

        case 'altaVenta':
        if (isset($_POST['sabor'], $_POST['tipo'], $_POST['cantidad'], $_POST['mail'])) {
            $listaHelados = Archivo::Leer(rutaHelados, 'Helado');
            $listaVentas = Archivo::Leer(rutaVentas,'Venta');
            $hayHelado=false;
            foreach ($listaHelados as &$value) {

                if ($value->BuscarPorSabor($_POST['sabor']) && $value->BuscarPorTipo($_POST['tipo'])) {
                    $hayHelado=true;
                    if ($value->GetCantidad() >= $_POST['cantidad']) {
                        
                        $value->SetCantidad(($value->GetCantidad()) - ($_POST['cantidad'])); 
                        $venta = new Venta($_POST['sabor'], $_POST['cantidad'], $_POST['tipo'], $_POST['mail']);
                        array_push($listaVentas,$venta);
                        echo "Se guardó la venta: ";
                        $venta->MostrarVenta();
                        break;

                    } else {
                        echo "<br> No hay cantidad suficiente de helado.<br>";
                    }
                }
            }
                if(!$hayHelado)
                    echo "No hay de ese gusto";
                Archivo::GuardarArray(rutaVentas, $listaVentas, 'w');
                Archivo::GuardarArray(rutaHelados, $listaHelados, 'w');
                unset($value);
            }


        break;

    case 'altaVentaConImagen':

        if (isset($_POST['sabor'], $_POST['tipo'], $_POST['cantidad'], $_POST['mail'], $_FILES['imagen'])) {

            $listaHelados = Archivo::Leer(rutaHelados, 'Helado');
            $listaVentas = Archivo::Leer(rutaVentas,'Venta');
            $hayHelado=false;
            foreach ($listaHelados as $value) {

                if ($value->BuscarPorSabor($_POST['sabor']) 
                && $value->BuscarPorTipo($_POST['tipo'])) {
                    $hayHelado=true;
                    if ($value->GetCantidad() >= $_POST['cantidad']) {
                        
                            $value->SetCantidad(($value->GetCantidad()) - ($_POST['cantidad']));
                        
                            $venta = new Venta($_POST['sabor'], $_POST['cantidad'], $_POST['tipo'], $_POST['mail']);
                            $venta->SetImagen($venta->GenerarNombreImg('imagen'));
                            if ($venta->GuardarImagen('imagen',rutaVentasImagenes)) {
                                echo "<br>Se ha guardado la imagen " . $venta->GetImagen() .
                                    " en la carpeta " . rutaVentasImagenes . "<br>";

                            array_push($listaVentas,$venta);
                            break;
                            }
                    }
                    else{
                        echo "No hay cantidad de helado suficiente.";
                    }
                } 
            }
            Archivo::GuardarArray(rutaVentas, $listaVentas,'w');
            Archivo::GuardarArray(rutaHelados, $listaHelados, 'w');
            if(!$hayHelado) echo "No hay helado de ese gusto.";
        }   
        else{
            echo "Faltan datos";
        }
        break;

    case 'tablaVentas':

        $ventas = Archivo::Leer(rutaVentas, 'Venta');
        if(isset($_GET['mail'])){
            $ventas = Archivo::Filtrar($ventas,'GetMail',$_GET['mail']);
        }
        elseif(isset($_GET['sabor'])){
            $ventas = Archivo::Filtrar($ventas,'GetSabor',$_GET['sabor']);
        }
        else{
        }
        echo Venta::MostrarVentas($ventas);
        break;

    case 'modificarHelado':

        if (isset($_POST['sabor'], $_POST['precio'], $_POST['tipo'], $_POST['cantidad'])) {

            $listaHelados = Archivo::Leer(rutaHelados, 'Helado');
            foreach ($listaHelados as &$helado) {

                if ($helado->BuscarPorSabor($_POST['sabor']) && $helado->BuscarPorTipo($_POST['tipo'])) {
                   
                    $helado = new Helado($_POST['sabor'], $_POST['precio'], $_POST['cantidad'], $_POST['tipo']);
                    if (isset($_FILES['imagen'])) {
                        if($helado->GetImagen()!=='')
                            if($helado->MoverImagenBackup(rutaHeladosImagenes,rutaBackupImagenes));
                                echo "Se ha movido la imagen con exito.";
                        $helado->SetImagen($helado->GenerarNombreImg('imagen'));
                        if($helado->GuardarImagen('imagen',rutaHeladosImagenes))
                            echo "\nSe ha guardado la imagen " . $helado->GetImagen() .
                                 " en la carpeta " . rutaHeladosImagenes . "<br>";
                    }
                    echo "\nSe ha modificado el Helado. \nDatos del Helado: ";
                    $helado->MostrarHelado();
                }
                else{
                    echo "No se encontró ese gusto de helado";
                }
            }
            Archivo::GuardarArray(rutaHelados, $listaHelados, 'w');
            unset($helado);
        }
        else{
            echo "Faltan datos";
        }
        break;

    case 'borrarHelado':

        if (isset($_POST['sabor'], $_POST['tipo'])) {

            $listaHelados = Archivo::Leer(rutaHelados, 'Helado');
            $contador=0;
            foreach ($listaHelados as $helado) {

                if ($helado->BuscarPorSabor($_POST['sabor']) 
                && $helado->BuscarPorTipo($_POST['tipo'])) {

                    if ($helado->GetImagen()!==null) {
                        $helado->MoverImagenBackup(rutaHeladosImagenes,rutaBackupImagenes);
                    }
                    array_splice($listaHelados, $contador, 1);
                    echo "Se borró el Helado con exito. Helado borrado: ";
                    $helado->MostrarHelado();
                    break;
                }
                $contador++;
            }
            Archivo::GuardarArray(rutaHelados, $listaHelados, 'w');
        }
        else{
            echo "Faltan datos";
        }

    case 'mostrarImagenes':
        if (isset($_GET['opcion'])) {
            if($_GET['opcion']==='cargadas'){
                echo Archivo::mostrarImagenes(rutaHeladosImagenes,'Imagenes Cargadas');
                echo "<br>";
                echo Archivo::mostrarImagenes(rutaVentasImagenes,'Imagenes Cargadas');
            }
            elseif($_GET['opcion']==='borradas'){
                echo "<br>";
                echo Archivo::mostrarImagenes(rutaBackupImagenes,'Imagenes Borradas');
            }
        }
        else{
            echo "Faltan datos";
        }
        break;
    
        default:
            echo "No hay opcion ingresada";
        break;

}


?>