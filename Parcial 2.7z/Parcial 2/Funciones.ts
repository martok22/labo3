namespace Modelo{
    
    export class Funciones{
        
        public static idCount;

        public static OnLoad():void{
            let lista:Alumno[] = Funciones.Generar();
            Funciones.LoadStorage(Alumno.ListaAlumnoAListaJASON(lista));
            Funciones.idCount = lista.length + 1;
            $(document).ready(function(){
                Funciones.CargarGrilla(lista); // Cargo grilla
                $('#mayoresA4').html(Funciones.CantNotasMayoresA4().toString()); // Cargo estadísticas
            }); 
        }

        public static ChequearCamposVacíos(){
            return ($('#formulario').children('input').val()=='')
        }

        public static ObtenerAlumno(id?:number):Alumno{ //Sin id -> Agregar - Con id -> Modificar
            let inputsID:string[] = [];
            //if(Funciones.ChequearCamposVacíos())
            (id!=null) ? (inputsID = inputsID.concat([id.toString(),'#nombreModal','#legajoModal','#materiaModal','#notaModal'])) : (inputsID = inputsID.concat([Funciones.idCount.toString(),'#nombre','#legajo','#materia','#nota']));
            let Alu:Alumno = new Alumno((Number)(inputsID[0]),
                                        (String)($(inputsID[1]).val()),
                                        (String)($(inputsID[2]).val()),
                                        (String)($(inputsID[3]).val()),
                                        (Number)($(inputsID[4]).val()));
            Funciones.idCount++;
            return Alu;
        } 

        public static CargarGrilla(lista:Alumno[]):void{
            ($('#grilla')).html(Funciones.PopularGrilla(lista));
            //(<HTMLInputElement>document.getElementById('grilla')).innerHTML=Funciones.PopularGrilla(lista);

        }

        public static DumpStorage():AlumnoJASON[]{
            let listaString:string = localStorage.getItem('listaAlumnos');
            let listaJSON:AlumnoJASON[] = JSON.parse(listaString);
            return listaJSON;
        }

        public static LoadStorage(listaJSON:AlumnoJASON[]):void{
            localStorage.setItem('listaAlumnos',JSON.stringify(listaJSON));
        }

        public static Accion(accion:string,id?:number):void{
            
            let listaJSON:AlumnoJASON[] = Funciones.DumpStorage();

            if(accion=='Agregar'){
                listaJSON.push(Alumno.ObjetoAJASON(Funciones.ObtenerAlumno()));
            }
            else{
                listaJSON.forEach(function(objeto:AlumnoJASON,index,lista){
                
                    if(accion=='Modificar'){
                        if(id!=null && objeto.id==id) {
                            lista[index] = Alumno.ObjetoAJASON(Funciones.ObtenerAlumno(id));
                        }
                    } 
                    else if(accion == 'Borrar'){
                        if(id!=null && objeto.id==id) {
                            lista.splice(index,1);
                        }
                    }
                })
            }
            Funciones.CargarGrilla(Alumno.ListaJasonAListaObjeto(listaJSON));
            Funciones.LoadStorage(listaJSON);
            
            
        }
        public static MostrarModal(){
            $("#myModal").modal("show");
        }
        
    
        public static OcultarModal(){
            $("#myBtn").click(function(){
                $("#myModal").modal("hide");
            });
        }

        

        public static Generar():Alumno[]{
            let miLista:Alumno[] = [];
            miLista.push(new Alumno(1,'Martin','12','Mate',4));
            miLista.push(new Alumno(2,'Jorge','13','Lengua',4));
            miLista.push(new Alumno(3,'German','12','Mate',6));
            return miLista;
            
        }

        public static CantNotasMayoresA4():number{
            let lista:AlumnoJASON[] = Funciones.DumpStorage();
            let listaVacia:AlumnoJASON[] = [];
            return lista.reduce(function(acum,alu,index,lista){
                if(alu.nota>4) acum++;
                return acum;
            },0);
        }

        public static Filtrar(){

            let inputNombre:string = (String)($('#searchBarNombre').val());
            let inputNota:string = (String)($('#searchBarNota').val());
            let lista = Funciones.DumpStorage();

            lista = lista.filter(function(objeto){
                return objeto.nombre.startsWith(inputNombre,0);
            })
            lista = lista.filter(function(objeto){
                return objeto.nota.toString().startsWith(inputNota,0);
            });             
            Funciones.CargarGrilla(Alumno.ListaJasonAListaObjeto(lista));
        }

        public static AgregarAttribute(id:number):void{
            ($('#modalSubmit')).attr('onclick','Modelo.Funciones.Accion("Modificar",'+id+');');
        }

        public static PopularGrilla(lista:Alumno[]):string{
            let tabla_string:string = "";

            // Encabezados
            tabla_string += '<div class="row">'
            tabla_string += '<div class="col-xs-1 col-sm-1 col-md-1" style="background-color:lavender">ID</div>'
            tabla_string += '<div class="col-xs-3 col-sm-3 col-md-3" style="background-color:lightcyan">Nombre</div> '
            tabla_string += '<div class="col-xs-1 col-sm-1 col-md-1" style="background-color:lightgray">Legajo</div>'
            tabla_string += '<div class="col-xs-3 col-sm-3 col-md-3" style="background-color:lightgreen">Materia</div> '
            tabla_string += '<div class="col-xs-1 col-sm-1 col-md-1" style="background-color:lightyellow">Nota</div> ' 
            tabla_string += '<div class="col-xs-3 col-sm-3 col-md-3" style="background-color:lavender">Editar</div> '
            tabla_string += '</div>';

            for(let contador=0, id=contador+1; contador<lista.length ;contador++){

                //
                tabla_string += "<div class='row' >"; //id="+"'"+contador+"'"+(parseInt(lista[contador].nota) <= 4 ? " class='menorA4'" : "")+"
                tabla_string += '<div class="col-xs-1 col-sm-1 col-md-1" style="background-color:lavender">' +lista[contador].GetId()+ '</div> ';
                tabla_string += '<div class="col-xs-3 col-sm-3 col-md-3" style="background-color:lightcyan">' +lista[contador].GetNombre()+ '</div> ';
                tabla_string += '<div class="col-xs-1 col-sm-1 col-md-1" style="background-color:lightgray">' +lista[contador].GetLegajo()+ '</div> '; 
                tabla_string += '<div class="col-xs-3 col-sm-3 col-md-3" style="background-color:lightgreen">' +lista[contador].GetMateria()+ '</div> ';
                tabla_string += '<div class="col-xs-1 col-sm-1 col-md-1" style="background-color:lightyellow">' +lista[contador].GetNota()+ '</div> ';
                
                // Botones
                tabla_string += '<div class="col-xs-3 col-sm-3 col-md-3""><button value="Editar" class="btn btn-primary"';
                tabla_string += ' data-toggle="modal" data-target="#myModal" onclick="Modelo.Funciones.AgregarAttribute('+lista[contador].GetId()+')"><i class="fas fa-pen-alt"></i></button>';
                tabla_string += '<button value="Borrar"';
                tabla_string += ' onclick="Modelo.Funciones.Accion(\'Borrar\',' + lista[contador].GetId() + ')" class="btn btn-primary custom"><i class="fas fa-trash-alt"></i></button></div>';
                tabla_string += "</div>"; //<div class="col-xs-6 col-sm-3 col-md-1" style="background-color:darksalmon"></div>
            }
            
            return tabla_string;
        }

    }
}
