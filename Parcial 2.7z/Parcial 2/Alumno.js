/// <reference path="Persona.ts"/>
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
//import Persona = require("Persona");
var Modelo;
(function (Modelo) {
    var Alumno = /** @class */ (function (_super) {
        __extends(Alumno, _super);
        function Alumno(id, nombre, legajo, materia, nota) {
            var _this = _super.call(this, id, nombre) || this;
            _this.legajo = legajo;
            _this.materia = materia;
            _this.nota = nota;
            return _this;
        }
        Alumno.ObjetoAJASON = function (objeto) {
            var miObjetoJson = {
                id: objeto.GetId(),
                nombre: objeto.GetNombre(),
                legajo: objeto.GetLegajo(),
                materia: objeto.GetMateria(),
                nota: objeto.GetNota()
            };
            return miObjetoJson;
        };
        Alumno.ListaJasonAListaObjeto = function (lista) {
            var retorno = [];
            lista.forEach(function (objeto) {
                retorno.push(Alumno.JASONAObjeto(objeto));
            });
            return retorno;
        };
        Alumno.ListaAlumnoAListaJASON = function (lista) {
            var retorno = [];
            lista.forEach(function (objeto) {
                retorno.push(Alumno.ObjetoAJASON(objeto));
            });
            return retorno;
        };
        Alumno.JASONAObjeto = function (jason) {
            return new Alumno(jason.id, jason.nombre, jason.legajo, jason.materia, jason.nota);
        };
        Alumno.prototype.GetLegajo = function () {
            return this.legajo;
        };
        Alumno.prototype.GetMateria = function () {
            return this.materia;
        };
        Alumno.prototype.GetNota = function () {
            return this.nota;
        };
        Alumno.prototype.toString = function () {
            return _super.prototype.toString.call(this) + '-' + this.GetLegajo() + '-' + this.GetMateria() + '-' + this.GetNota();
        };
        return Alumno;
    }(Modelo.Persona));
    Modelo.Alumno = Alumno;
})(Modelo || (Modelo = {}));
