let lista = [];
lista = lista.concat(['algo']);
lista.forEach(function(algo){
console.log(algo);
});
