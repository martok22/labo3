var Modelo;
(function (Modelo) {
    var Persona = /** @class */ (function () {
        function Persona(id, nombre) {
            this.nombre = nombre;
            this.id = id;
        }
        /*public toJSON():object{
            return JSON.parse("{nombre: "+this.nombre+"}");
        }*/
        Persona.prototype.toString = function () {
            return this.GetId() + '-' + this.GetNombre();
        };
        Persona.prototype.GetNombre = function () {
            return this.nombre;
        };
        Persona.prototype.GetId = function () {
            return this.id;
        };
        return Persona;
    }());
    Modelo.Persona = Persona;
})(Modelo || (Modelo = {}));
