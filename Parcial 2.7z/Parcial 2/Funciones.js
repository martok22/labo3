var Modelo;
(function (Modelo) {
    var Funciones = /** @class */ (function () {
        function Funciones() {
        }
        Funciones.OnLoad = function () {
            var lista = Funciones.Generar();
            Funciones.LoadStorage(Modelo.Alumno.ListaAlumnoAListaJASON(lista));
            Funciones.idCount = lista.length + 1;
            $(document).ready(function () {
                Funciones.CargarGrilla(lista); // Cargo grilla
                $('#mayoresA4').html(Funciones.CantNotasMayoresA4().toString()); // Cargo estadísticas
            });
        };
        Funciones.ChequearCamposVacíos = function () {
            return ($('#formulario').children('input').val() == '');
        };
        Funciones.ObtenerAlumno = function (id) {
            var inputsID = [];
            //if(Funciones.ChequearCamposVacíos())
            (id != null) ? (inputsID = inputsID.concat([id.toString(), '#nombreModal', '#legajoModal', '#materiaModal', '#notaModal'])) : (inputsID = inputsID.concat([Funciones.idCount.toString(), '#nombre', '#legajo', '#materia', '#nota']));
            var Alu = new Modelo.Alumno((Number)(inputsID[0]), (String)($(inputsID[1]).val()), (String)($(inputsID[2]).val()), (String)($(inputsID[3]).val()), (Number)($(inputsID[4]).val()));
            Funciones.idCount++;
            return Alu;
        };
        Funciones.CargarGrilla = function (lista) {
            ($('#grilla')).html(Funciones.PopularGrilla(lista));
            //(<HTMLInputElement>document.getElementById('grilla')).innerHTML=Funciones.PopularGrilla(lista);
        };
        Funciones.DumpStorage = function () {
            var listaString = localStorage.getItem('listaAlumnos');
            var listaJSON = JSON.parse(listaString);
            return listaJSON;
        };
        Funciones.LoadStorage = function (listaJSON) {
            localStorage.setItem('listaAlumnos', JSON.stringify(listaJSON));
        };
        Funciones.Accion = function (accion, id) {
            var listaJSON = Funciones.DumpStorage();
            if (accion == 'Agregar') {
                listaJSON.push(Modelo.Alumno.ObjetoAJASON(Funciones.ObtenerAlumno()));
            }
            else {
                listaJSON.forEach(function (objeto, index, lista) {
                    if (accion == 'Modificar') {
                        if (id != null && objeto.id == id) {
                            lista[index] = Modelo.Alumno.ObjetoAJASON(Funciones.ObtenerAlumno(id));
                        }
                    }
                    else if (accion == 'Borrar') {
                        if (id != null && objeto.id == id) {
                            lista.splice(index, 1);
                        }
                    }
                });
            }
            Funciones.CargarGrilla(Modelo.Alumno.ListaJasonAListaObjeto(listaJSON));
            Funciones.LoadStorage(listaJSON);
        };
        Funciones.MostrarModal = function () {
            $("#myModal").modal("show");
        };
        Funciones.OcultarModal = function () {
            $("#myBtn").click(function () {
                $("#myModal").modal("hide");
            });
        };
        Funciones.Generar = function () {
            var miLista = [];
            miLista.push(new Modelo.Alumno(1, 'Martin', '12', 'Mate', 4));
            miLista.push(new Modelo.Alumno(2, 'Jorge', '13', 'Lengua', 4));
            miLista.push(new Modelo.Alumno(3, 'German', '12', 'Mate', 6));
            return miLista;
        };
        Funciones.CantNotasMayoresA4 = function () {
            var lista = Funciones.DumpStorage();
            var listaVacia = [];
            return lista.reduce(function (acum, alu, index, lista) {
                if (alu.nota > 4)
                    acum++;
                return acum;
            }, 0);
        };
        Funciones.Filtrar = function () {
            var inputNombre = (String)($('#searchBarNombre').val());
            var inputNota = (String)($('#searchBarNota').val());
            var lista = Funciones.DumpStorage();
            lista = lista.filter(function (objeto) {
                return objeto.nombre.startsWith(inputNombre, 0);
            });
            lista = lista.filter(function (objeto) {
                return objeto.nota.toString().startsWith(inputNota, 0);
            });
            Funciones.CargarGrilla(Modelo.Alumno.ListaJasonAListaObjeto(lista));
        };
        Funciones.AgregarAttribute = function (id) {
            ($('#modalSubmit')).attr('onclick', 'Modelo.Funciones.Accion("Modificar",' + id + ');');
        };
        Funciones.PopularGrilla = function (lista) {
            var tabla_string = "";
            // Encabezados
            tabla_string += '<div class="row">';
            tabla_string += '<div class="col-xs-1 col-sm-1 col-md-1" style="background-color:lavender">ID</div>';
            tabla_string += '<div class="col-xs-3 col-sm-3 col-md-3" style="background-color:lightcyan">Nombre</div> ';
            tabla_string += '<div class="col-xs-1 col-sm-1 col-md-1" style="background-color:lightgray">Legajo</div>';
            tabla_string += '<div class="col-xs-3 col-sm-3 col-md-3" style="background-color:lightgreen">Materia</div> ';
            tabla_string += '<div class="col-xs-1 col-sm-1 col-md-1" style="background-color:lightyellow">Nota</div> ';
            tabla_string += '<div class="col-xs-3 col-sm-3 col-md-3" style="background-color:lavender">Editar</div> ';
            tabla_string += '</div>';
            for (var contador = 0, id = contador + 1; contador < lista.length; contador++) {
                //
                tabla_string += "<div class='row' >"; //id="+"'"+contador+"'"+(parseInt(lista[contador].nota) <= 4 ? " class='menorA4'" : "")+"
                tabla_string += '<div class="col-xs-1 col-sm-1 col-md-1" style="background-color:lavender">' + lista[contador].GetId() + '</div> ';
                tabla_string += '<div class="col-xs-3 col-sm-3 col-md-3" style="background-color:lightcyan">' + lista[contador].GetNombre() + '</div> ';
                tabla_string += '<div class="col-xs-1 col-sm-1 col-md-1" style="background-color:lightgray">' + lista[contador].GetLegajo() + '</div> ';
                tabla_string += '<div class="col-xs-3 col-sm-3 col-md-3" style="background-color:lightgreen">' + lista[contador].GetMateria() + '</div> ';
                tabla_string += '<div class="col-xs-1 col-sm-1 col-md-1" style="background-color:lightyellow">' + lista[contador].GetNota() + '</div> ';
                // Botones
                tabla_string += '<div class="col-xs-3 col-sm-3 col-md-3""><button value="Editar" class="btn btn-primary"';
                tabla_string += ' data-toggle="modal" data-target="#myModal" onclick="Modelo.Funciones.AgregarAttribute(' + lista[contador].GetId() + ')"><i class="fas fa-pen-alt"></i></button>';
                tabla_string += '<button value="Borrar"';
                tabla_string += ' onclick="Modelo.Funciones.Accion(\'Borrar\',' + lista[contador].GetId() + ')" class="btn btn-primary custom"><i class="fas fa-trash-alt"></i></button></div>';
                tabla_string += "</div>"; //<div class="col-xs-6 col-sm-3 col-md-1" style="background-color:darksalmon"></div>
            }
            return tabla_string;
        };
        return Funciones;
    }());
    Modelo.Funciones = Funciones;
})(Modelo || (Modelo = {}));
