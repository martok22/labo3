/// <reference path="Persona.ts"/>

//import Persona = require("Persona");
namespace Modelo{
    
    export type AlumnoJASON = {id:number,nombre:string,legajo:string,materia:string,nota:number};

    export class Alumno extends Persona{

        private legajo:string;
        private materia:string;
        private nota:number;

        constructor(id:number, nombre:string, legajo:string, materia:string, nota:number){
            super(id,nombre);
            this.legajo = legajo;
            this.materia = materia;
            this.nota = nota;
        }

        public static ObjetoAJASON(objeto:Alumno):AlumnoJASON{
           
            let miObjetoJson:AlumnoJASON = {
                id: objeto.GetId(),
                nombre: objeto.GetNombre(),
                legajo: objeto.GetLegajo(),
                materia: objeto.GetMateria(),
                nota: objeto.GetNota(),
            }
            return miObjetoJson;
        }

        public static ListaJasonAListaObjeto(lista:AlumnoJASON[]){

            let retorno:Alumno[] = [];
            lista.forEach(function(objeto){
                retorno.push(Alumno.JASONAObjeto(objeto));
            });
            return retorno;
        }

        public static ListaAlumnoAListaJASON(lista:Alumno[]){

            let retorno:AlumnoJASON[] = [];
            lista.forEach(function(objeto){
                retorno.push(Alumno.ObjetoAJASON(objeto));
            });
            return retorno;
        }

        public static JASONAObjeto(jason:AlumnoJASON):Alumno{
            return new Alumno(jason.id,jason.nombre,jason.legajo,jason.materia,jason.nota);
        }

        public GetLegajo():string{
            return this.legajo;
        }

        public GetMateria():string{
            return this.materia;
        }

        public GetNota():number{
            return this.nota;
        }

        public toString():string{
            return super.toString()+'-'+this.GetLegajo()+'-'+this.GetMateria()+'-'+this.GetNota();
        }

    }
}

