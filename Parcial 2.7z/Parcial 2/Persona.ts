namespace Modelo{
    export class Persona {
        
        public nombre:string;
        public id:number;
    
        constructor(id:number,nombre:string){
            this.nombre = nombre;
            this.id = id;
        }

        /*public toJSON():object{
            return JSON.parse("{nombre: "+this.nombre+"}");
        }*/

        public toString():string{
            return this.GetId()+'-'+this.GetNombre();
        }


        public GetNombre():string{
            return this.nombre;
        }
        

        public GetId():number{
            return this.id;
        }
    }

}

