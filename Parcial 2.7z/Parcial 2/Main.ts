/// <reference path="Persona.ts"/>
/// <reference path="Alumno.ts"/>
/// <reference path="Funciones.ts"/>

// Agregar todos los archivos en script del html, y ojo el orden (se ejecutan de arriba a abajo)
namespace Modelo{
    
    /*export class Main{
        public static main():void {
            let unaPersona:Persona = new Persona("Jorge");
            let unAlumno:Alumno = new Alumno("Jorge","123","Matematica",4);
            console.log(unAlumno.toString());
            console.log(unAlumno.json());
            console.log(JSON.stringify(unAlumno));
            let lista:Array<Alumno> = Funciones.Filtrar();
            
        }
    }*/
    Funciones.OnLoad();
    
    

    //let a:Persona = new Persona("Mariano");
}

/*interface Animal{
        hacerRuido();
    }
    
    class Perro{
        private nombre;
    
        public constructor{
            this.nombre = "Jorge";
        }
    }*/

    /*let animal:gato = new gato();
    $('#id').val('lago');*/