<?php
    class Persona{
        private $nombre;
        private $apellido;
        private $edad;
        private $legajo;
        private $nombre_imagen;
        private $Lista;

        public function __construct($nom, $ape, $leg, $ed,$nombre_img){
            $this->nombre = $nom;
            $this->apellido = $ape;
            $this->edad = $ed;
            $this->legajo = $leg;
            $this->nombre_imagen = $nombre_img;
            $this->Lista = array();
        }

        public function __get($prop){
            return $this->$prop;
        }

        public function __set($prop, $value){
            $this->$prop = $value;
        }

        public function __toString(){
            $frase = $this->nombre . "-" . $this->apellido . "-" . $this->edad . "-" . $this->legajo . "-" . $this->nombre_imagen . PHP_EOL;
            return $frase;
        }

        // Carga personas desde archivo.txt al campo Lista de Persona.
        public function Cargar(){
            $pArchivo = fopen("archivo.txt","r");
            if($pArchivo!=false){
                while(!feof($pArchivo))
                {
                    $persona = explode("-",fgets($pArchivo));
                    $this->Lista[] = $persona;
                }
            }
            else{
                echo "<br> No se pudo abrir el archivo <br>";
            }
            if (fclose($pArchivo)) echo "<br> Se cerro el archivo correctamente <br>";
            else
                echo "<br> No se pudo cerrar el archivo. <br>";
        }
        // Tiene que modificar atributos, y cuando se agrega imagen, copiar la imagen vieja a una carpeta de backup, subir la nueva y 
        // escribirla en el archivo txt
        public function Modificar(){
            foreach($this->Lista as &$value)
            {
                //echo $value[2] . '<br>';
                //echo '<br>' . $this->legajo . '<br>';
                if($value[2] == $this->legajo){
                    echo "<br>Se encontró un registro a modificar. <br>";

                    // Copio imagen a backup, borro.
                    copy("./Imagenes/$value[4]","./Imagenes-Backup/$value[4]");
                    unlink("./Imagenes/$value[4]");

                    // Reemplazo datos
                    $value[0] = $this->nombre;
                    $value[1] = $this->apellido;
                    $value[3] = $this->edad;
                    $value[4] = $this->nombre_imagen;
                }    
            }
            
            //echo "<br>" . $this->Lista[1][0] ." ". $this->Lista[1][1] . "<br>";
            $this->GuardarTodo();
        }

        public function Borrar(){
            // Lees archivo, cargas personas en array, no grabas las que queres borrar
            $contador = 0; $contadorPost = 0;
            foreach($this->Lista as $value)
            {
                if($value[2] == $_POST['legajo']){
                    $contadorPosta = $contador;
                    $string = trim($value[4]);
                    copy("./Imagenes/$string","./Imagenes-Backup/$string");
                    unlink("./Imagenes/$string");
                    //unset($value);      
                }
                $contador++;    
            }

            // Borro fila, reordeno indices
            unset($this->Lista[$contadorPosta]);
            $this->Lista = array_values($this->Lista);

            $this->GuardarTodo();
        }

        public function Guardar(){
            if(!empty($this->Lista)){  
                    $pArchivo = fopen("archivo.txt","a");
                    fwrite($pArchivo,"$this");
                    fclose($pArchivo); 
                } 
        }

        public function GuardarTodo(){
            // $var = is_writable("archivo.txt"); echo $var . "<br>";
            $pArchivo = fopen("archivo.txt","w");
            if($pArchivo != false)
            {
                //var_dump($pArchivo);
                //echo "<br>" . "$pArchivo";
                foreach($this->Lista as $value){
                    // template persona
                    //var_dump($value);
                    $nombre = $value[0]; $apellido = $value[1]; $legajo = $value[2]; $edad = $value[3]; $nombre_img = $value[4];
                    if($nombre != "" && $apellido != "" && $legajo != "" && $edad != "" && $nombre_img != ""){
                        $persona = $nombre . '-' . $apellido . '-' . $legajo . '-' . $edad . '-' . $nombre_img;
                        //echo $persona;
                        $cantEscrita = fwrite($pArchivo,$persona,strlen($persona));
                        var_dump($cantEscrita);
                        echo $cantEscrita . "<br>";
                    }
                }
            }
            else{
                echo "<br> Problemas al abrir el archivo para escribir <br>";
            }
            if (fclose($pArchivo)) echo "<br> El archivo se cerró correctamente. <br>"; 
            
        }
        public function MostrarArray(){
            $contador = 0;
            foreach($this->Lista as $value){
                echo "Fila N°$contador: <br>";
                var_dump($value);
            }
        }
        public function MostrarArchivo(){
            
        }
    }
?>