<?php
    $pArchivo = fopen("./Imagenes/texto.txt","w");
    close($pArchivo);
    ?>