    
        var httpReq = new XMLHttpRequest();
        var callBack = function(){
            console.log("Llego info del servidor" + httpReq.readyState);
            //window.onload = funcionInicial
            // Fijarte que hace la funcion splice
            // Como sacar el evento por defecto: 
            if(httpReq.readyState==4)
            {
                if(httpReq.status==200)
                {//para mandar JSON en peticion post, cambiar el header (Content-type,'application')
                    //console.log(httpReq.responseText);
                    var obj = JSON.parse(httpReq.responseText);
                    // localstorage se usa para guardar registros de datos estaticos (que no haya que agregar filas)
                    // Siempre hay q hacer un getItem de personas 
                    localStorage.setItem('personas',JSON.stringify(obj));
                    if()
                    console.log(localStorage.getItem('personas'));
                    var tabla = crearTabla(obj);
                    document.getElementById("cuerpo").innerHTML += tabla;
                    if(httpReq.responseText=='true'){
                    }
                    else{
                    }
                }
                else{            
                    alert("error en el servidor");
                    console.log(httpReq.responseText);
                }  
            }
        }

function ajax(){
            httpReq.onreadystatechange=callBack;
            httpReq.open("GET","http://localhost:3000/personas",true);
            httpReq.send();
}

function crearTabla(lista){
    var tabla_string = "<table>";
    tabla_string += "<th>Nombre</th><th>Apellido</th><th>Fecha</th><th>Telefono</th><th>Borrar</th>"

    for(contador=0;contador<50;contador++){
        tabla_string += "<tr id='td_"+contador+"'><td>" +lista[contador].nombre+ "</td><td>" +lista[contador].apellido+ "</td> <td>";
        tabla_string += lista[contador].fecha+ "</td><td>" +lista[contador].telefono+ "</td><td><button value='Borrar' onclick=Borrar("+contador+")>Borrar</button></td></tr>";
    }
    tabla_string += "</table>";
    return tabla_string;
}

function Borrar(num_fila){
    document.getElementById("td_"+num_fila).value = "";
}