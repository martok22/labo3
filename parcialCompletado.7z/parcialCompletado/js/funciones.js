var httpReq = new XMLHttpRequest();
var result;
var cargado = false;

function ajaxResultPOST(result) {
    if (result.result === 'ok' && result.desc.match("^Alta")){ //Alta
        console.log('success');
        RefreshPage();
        MostrarSpinner('ocultar');
    }
    else if(result.desc==='Baja exitosa'){ //Baja
        console.log('Borrado con exito');
        RefreshPage();
    }
    else if(result.match('{')){ //Modificar.
        $('#inputFabricante').val(result.car_make);
        $('#inputColor').val(result.color);
    }   
    else {
        console.log('error');
    }
    console.log(result);
}

function ajaxResultGET(result) {
        $("#tabla").html(crearTabla(JSON.parse(result)));
        guardarEnLStorage(result);
}
function Ajax(metodo, direccion, datos) {
    $.ajax({
        url: direccion,
        type: (metodo == 'POST' ? 'POST' : 'GET'), 
        setRequestHeader: '"Content-Type",'+(metodo==="POST"?'"application/json"':'"x-www-form-urlencoded"'), // //application/json x-www-form-urlencoded
        data: datos,
        success: function (result) {
            if (this.type == 'POST')
                ajaxResultPOST(result);
            else
                ajaxResultGET(result);
        }
    });
}

$(document).ready(function () {
    RefreshPage();
});


function RefreshPage() {
    Ajax('GET', 'http://localhost:3000/traerAutos', ['']);
}

function BotonAgregar() {
    if(ValidarData()){
        MostrarSpinner('mostrar');
        data = getDataAgregar();
        Ajax('POST', 'http://localhost:3000/agregar', data);
    }
}

function BotonModificar(contador) {
    Ajax('GET','http://localhost:3000/traerAuto',{indice:contador});
}

function BotonBorrar(contador) {
    data = 0;
    let listaAutos = JSON.parse(localStorage.getItem('autos'));
    listaAutos.forEach(function(item,index,lista){
        if(index===contador) {
            data=index;
            console.log(data);
        }
    })
    if(data!==0) Ajax('POST','http://localhost:3000/eliminar',{indice:data});
}

function crearTabla(lista) {

    tabla_string = "<thead>" +
        "<th>Fabricante</th>" +
        "<th>Modelo</th>" +
        "<th>Color</th>" +
        "<th>Editar</th>" +
        "<th>Borrar</th></thead>";
    tabla_string += '<tbody>';
    for (contador = 0; contador < lista.length; contador++) {
        tabla_string += "<tr id=" + "'" + contador + "'" + ">";
        tabla_string += "<td>" + lista[contador].car_make + "</td>";
        tabla_string += "<td>" + lista[contador].model_year + "</td>";
        tabla_string += "<td>" + lista[contador].color + "</td>";
        tabla_string += '<td><button value="Editar" onclick="BotonModificar('+contador+')">Editar</button></td>';
        tabla_string += '<td><button value="Borrar" onclick="BotonBorrar('+contador+')">Borrar</button></td></tr></tbody>';
    }
    return tabla_string;
}


/** Chequea que los campos sean validos. Cambia CSS Y RETORNA BOOLEANO
 *  
 */

function ValidarData(){
    if($('#inputFabricante').val().length>3 && $('#inputColor').val().length>3){
        $('#inputColor').css('border-color', '');
        $('#inputFabricante').css('border-color', '');
        return true;
    }
    else{
        $('#inputColor').css('border-color', 'red');
        $('#inputFabricante').css('border-color', 'red');
        return false;
    }
}

function getDataAgregar() {
    let lista = {
        car_make: $('#inputFabricante').val(),
        model_year: $('#inputModelo').val(),
        color: $('#inputColor').val()
    };
    return lista;

}

function CerrarPopUp(){
    $('#formModificar').css('display', 'none');
}

function guardarEnLStorage(response) {
    localStorage.setItem("autos", response);
}

function MostrarSpinner(opcion) {
    let propiedad = '';
    if (opcion === 'mostrar') propiedad = 'block';
    else if (opcion === 'ocultar') propiedad = 'none';
    $('#divSpinner').css('display', propiedad);
}


