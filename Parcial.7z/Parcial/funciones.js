var httpReq = new XMLHttpRequest();
var listaJSON;
var cargado = false;
        
var callBack_GET = function(){
            console.log("Llego info del servidor" + httpReq.readyState);
            console.log("callbackGET");

            if(httpReq.readyState==4)
            {
                if(httpReq.status==200)
                {
                    listaJSON = JSON.parse(httpReq.responseText);
                    document.getElementById("tabla").innerHTML = crearTabla(listaJSON);
                    
                }
                else{            
                    alert("error en el servidor");
                    console.log(httpReq.responseText);
                }  
            }
        }
        var callBack_POST = function(){
            console.log("Llego info del servidor" + httpReq.readyState);
            console.log("callbackPOST");

            if(httpReq.readyState==4)
            {
                if(httpReq.status==200)
                {
                    listaJSON = JSON.parse(httpReq.responseText);
                    if(listaJSON.type!='error' && (listaJSON.type == 'User' || listaJSON.type == 'Admin')){
                        guardarEnLStorage(listaJSON);
                    }
                    if(listaJSON.type=='ok') console.log("Se editó con éxito.");
                    cargado = true;
                    
                }
                else{
                    mensaje = httpReq.responseText;
                    console.log(httpReq.responseText);
                    console.log(httpReq.responseType);
                    console.log(httpReq.status);
                    console.log(httpReq.statusText);    
                    alert("error en el servidor");
                    console.log(httpReq.responseText);
                    mensaje = httpReq.responseText;
                }  
            }
        }


function ajax(metodo, url, parametro){
            
            if(metodo=='GET'){
                httpReq.onreadystatechange = callBack_GET;
                httpReq.open(metodo,url,true);
                httpReq.send();
            }
            else if(metodo=='POST'){
                httpReq.onreadystatechange=callBack_POST;
                httpReq.open(metodo,url,true);
                httpReq.setRequestHeader("Content-Type","application/json");
                httpReq.send(parametro());
            }
}

function crearTabla(lista){
    
    tabla_string =  "<th>NRO</th>"+
                    "<th>Id</th>"+
                    "<th>Legajo</th>"+
                    "<th>Nombre</th>"+
                    "<th>Materia</th>"+
                    "<th>Nota</th>";
    
    (localStorage.getItem('type')==='Admin') ? (tabla_string+="<th></th>") : "";
    
    for(contador=0, id=contador; contador<lista.length ;contador++){
        if(lista[contador]==undefined) {
            id=contador-1;
            continue;
        }

        tabla_string += "<tr id="+"'"+contador+"'"+(parseInt(lista[contador].nota) <= 4 ? " class='menorA4'" : "")+"><td>"+contador+"</td>";
        tabla_string += "<td>" +lista[contador].id+ "</td>";
        tabla_string += "<td>" +lista[contador].legajo+ "</td>"; 
        tabla_string += "<td>" +lista[contador].nombre+ "</td>";
        tabla_string += "<td>" +lista[contador].materia+ "</td>";
        tabla_string += "<td>" +lista[contador].nota+ "</td>";
        (localStorage.getItem('type')==='Admin') ? (tabla_string += '<td><button value="Editar" onclick="mostrarPopUp('+lista[contador].id+')">Editar</button></td></tr>') : "</tr>";
    }
    return tabla_string;
}


function getUserData(){
    var correo = document.getElementById("email").value;
    var contraseña = document.getElementById("password").value;
    var datosLogin = {
        email: correo,
        password: contraseña
    }
    return JSON.stringify(datosLogin);
}

function getRowToEdit(){
    var datosEdit = {
        id: filaAEditar,
        legajo: document.getElementById('legajo').value,
        nombre: document.getElementById('nombre').value,
        materia: document.getElementById('materia').value,
        nota: document.getElementById('nota').value
    }
    return JSON.stringify(datosEdit);
}

function guardarEnLStorage(response){
    localStorage.setItem("email",document.getElementById("email").value);
    localStorage.setItem("type",response.type);
}

function testContraseña(){
    if(document.getElementById('password').value != '1234')
        document.getElementById('errorMsg').className = 'Mostrar';
    else
        document.getElementById('errorMsg').className = 'oculto';
        
}

function MostrarIcon(){
    document.getElementById('spinner').style.display = 'block';
}

function cargarIndex(){
    var cronometro = setTimeout(function(){
        //if(cargado){
            //location.href='index.html';
            location.href = 'index.html';
            ajax('POST','http://localhost:3000/login',getUserData); testContraseña(); MostrarIcon();
            //window.ajax('GET','http://localhost:3000/notas','window.getUserData');
        //}
    },3000);
}
//console.log(document.getElementById('body').value);
//window.onload = window.