
var fire = setTimeout(laFuncion,3000);

var contador = 0;
var tempo = setInterval(primera,1);
var mensaje;
var filaAEditar;

function laFuncion(){
    //location.href='login.html';
    ajax('GET','http://localhost:3000/notas','getUserData');
}

function off(){
    clearInterval(tempo);
}

function primera(){
    contador++;
    if(contador==15000) off();
    if(contador==13000) console.log(mensaje);
}

window.onclick = function(event){
    if (event.target == miPopUp){
        miPopUp.style.display = "none";
    }
}
window.onload = A;
var miPopUp;
function A(){
    miPopUp = document.getElementById('popUp-container');
    console.log(document.getElementsByTagName('body'));
    console.log(miPopUp);
}
function mostrarPopUp(id){
    miPopUp.style.display = 'block';
    filaAEditar = id;
}

 