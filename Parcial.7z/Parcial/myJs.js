window.onload = A;
var B;
var C = 3;
function A(){
    this.B = document.getElementById('some_div');
    console.log(B);
}

//console.log(B.value);
console.log(typeof(B));
function otro(){
    C = 5;
}

console.log(C); otro(); console.log(C);
